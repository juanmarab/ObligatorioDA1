﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using ObligatorioDA1.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1Test
{
    [TestClass]
    public class FunctionTest
    {
        [TestMethod]
        public void TestCreateFunction_OK()
        {
            Function expectedFunction = MockFunction();
            Function actualFunction = new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);

            Assert.AreEqual(expectedFunction.DateStart, actualFunction.DateStart);
            Assert.AreEqual(expectedFunction.DateEnd, actualFunction.DateEnd);
            Assert.AreEqual(expectedFunction.AvailableTickets, actualFunction.AvailableTickets);

        }

        [TestMethod]
        public void TestCreatePresentialFunction_OK()
        {
            string dateStart = "2022-01-01";
            string hourStart = "10:00";
            string dateEnd = "2022-01-01";
            string hourEnd = "11:30";

            DateTime dateTimeStart = Utils.BuildDate(dateStart, hourStart);
            DateTime dateTimeEnd = Utils.BuildDate(dateEnd, hourEnd);

            Function expectedFunction = new Function(dateTimeStart, dateTimeEnd, new List<Ticket>(), 150);

            Function actualFunction = Function.CreateFunction(dateStart, hourStart, dateEnd, hourEnd, new List<Ticket>(),  150);

            Assert.AreEqual(expectedFunction.DateStart, actualFunction.DateStart);
            Assert.AreEqual(expectedFunction.DateEnd, actualFunction.DateEnd);
            Assert.AreEqual(expectedFunction.AvailableTickets, actualFunction.AvailableTickets);
        }

        [TestMethod]
        public void TestGetTicketByName()
        {
            Function functionMock = MockFunction();
            Ticket ticketMock = MockTicket();
            functionMock.Tickets.Add(ticketMock);

            Ticket ticket = functionMock.GetTicketByName(ticketMock.Name);

            Assert.AreEqual(functionMock.Tickets[0], ticket);
        }

        [TestMethod]
        public void TestGetTicketByName_Throw()
        {
            Function functionMock = MockFunction();
            Ticket ticketMock = MockTicket();
            functionMock.Tickets.Add(ticketMock);

            Assert.ThrowsException<ObjectNotExistsException>(() => functionMock.GetTicketByName("badName"));
        }

        [TestMethod]
        public void TestDecrementTicketQuantity()
        {
            Function functionMock = MockFunction();
            Ticket ticketMock = MockTicket();
            functionMock.Tickets.Add(ticketMock);

            functionMock.DecrementTicketQuantity(ticketMock.Name);

            Ticket ticket = functionMock.GetTicketByName(ticketMock.Name);

            Assert.AreEqual(18899, ticket.Available);
        }


        [TestMethod]
        public void TestFunctionToString()
        {
            Function functionMock = MockFunction();
            string expected = "Start: 2022-01-01 - End: 2022-01-01 - Available Tickets: 150";
            string actual = functionMock.ToString();
            
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestFunctionEquals_OK()
        {
            Function functionA = MockFunction();
            Function functionB = MockFunction();

            Assert.IsTrue(functionA.Equals(functionB));
        }

        [TestMethod]
        public void TestFunctionEquals_FalseA()
        {
            Function functionA = MockFunction();
            Ticket ticket = MockTicket();

            Assert.IsFalse(functionA.Equals(ticket));
        }

        [TestMethod]
        public void TestFunctionEquals_FalseB()
        {
            Function functionA = MockFunction();
            Function functionB = null;

            Assert.IsFalse(functionA.Equals(functionB));
        }

        [TestMethod]
        public void TestFunctionEquals_FalseC()
        {
            Function functionA = MockFunction();
            Function functionB = MockFunction();

            functionB.DateStart = DateTime.Now;

            Assert.IsFalse(functionA.Equals(functionB));
        }

        [TestMethod]
        public void TestFunctionEquals_FalseD()
        {
            Function functionA = MockFunction();
            Function functionB = MockFunction();

            functionB.DateStart = DateTime.Now;
            functionB.DateStart = DateTime.Now;
            Assert.IsFalse(functionA.Equals(functionB));
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }
    }
}
