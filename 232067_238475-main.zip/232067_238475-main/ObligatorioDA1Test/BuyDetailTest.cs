﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using ObligatorioDA1;

namespace ObligatorioDA1Test
{
    /// <summary>
    /// Descripción resumida de UnitTest1
    /// </summary>
    [TestClass]
    public class BuyDetailTest
    {
        [TestMethod]
        public void TestToString()
        {
            DateTime date = DateTime.Now;
            BuyDetail buyDetail = new BuyDetail("random1234", MockFunction(), MockTicket());

            string expected = "random1234 - Tribuna Olimpica - Start: 2022-01-01 - End: 2022-01-01";
            string actual = buyDetail.ToString();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestCreateBuyDetail()
        {
            Function function = MockFunction();
            Ticket ticket = MockTicket();
            DateTime date = DateTime.Now;
            
            BuyDetail buyDetail = new BuyDetail("random1234", function, ticket);

            BuyDetail buyDetailActual = BuyDetail.CreateBuyDetail(function, ticket);

            Assert.AreEqual(buyDetail.TicketBought.Name, buyDetailActual.TicketBought.Name);
        }

        [TestMethod]
        public void TestCalculateTotalCost()
        {
            Function function = MockFunction();
            Ticket ticket = MockTicket();
            DateTime date = DateTime.Now;

            BuyDetail buyDetail = new BuyDetail("random1234", function, ticket);

            List <BuyDetail> list = new List<BuyDetail> { buyDetail };
            Assert.AreEqual(300, BuyDetail.CalculateTotalCost(list));
        }

        [TestMethod]
        public void TestGenerateTickets()
        {
            Function function = MockFunction();
            Ticket ticket = MockTicket();
            DateTime date = DateTime.Now;

            BuyDetail buyDetail = new BuyDetail("random1234", function, ticket);

            List<BuyDetail> expected = new List<BuyDetail> { buyDetail };

            Assert.AreEqual(expected[0].TicketBought.Name, BuyDetail.GenerateTickets(function,ticket,1)[0].TicketBought.Name);
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }
    }
}
