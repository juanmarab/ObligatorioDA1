﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using ObligatorioDA1;

namespace ObligatorioDA1Test
{
    /// <summary>
    /// Descripción resumida de UnitTest1
    /// </summary>
    [TestClass]
    public class TicketTest
    {
        [TestMethod]
        public void TestTicketEquals_OK()
        {
            Ticket ticketA = MockTicket();
            Ticket ticketB = MockTicket();
            
            Assert.IsTrue(ticketA.Equals(ticketB));
        }

        [TestMethod]
        public void TestTicketEquals_False()
        {
            Ticket ticketA = MockTicket();
            Ticket ticketB = null;
            
            Assert.IsFalse(ticketA.Equals(ticketB));
        }

        [TestMethod]
        public void TestTicketEquals_FalseA()
        {
            Ticket ticketA = MockTicket();
            Function function = MockFunction();
            
            Assert.IsFalse(ticketA.Equals(function));
        }

        [TestMethod]
        public void TestTicketEquals_FalseB()
        {
            Ticket ticketA = MockTicket();
            ticketA.Name = "Other Name";
            Ticket ticketB = MockTicket();
            
            Assert.IsFalse(ticketA.Equals(ticketB));
        }

        [TestMethod]
        public void TestTicketEquals_FalseC()
        {
            Ticket ticketA = MockTicket();
            ticketA.Name = "Other Name";
            ticketA.Price = 0;
            Ticket ticketB = MockTicket();
            
            Assert.IsFalse(ticketA.Equals(ticketB));
        }

        [TestMethod]
        public void TestTicketToString()
        {
            Ticket ticketA = MockTicket();
            string expected = "Tribuna Olimpica - Price: 300 - Quantity: 18900";
 
            Assert.AreEqual(expected,ticketA.ToString());
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);
        }
    }
}
