﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioDA1Test
{
    [TestClass]
    public class BuyTest
    {

        [TestMethod]
        public void TestGetAssistantId()
        {
            Buy buy = MockBuy();
            Assert.AreEqual("53537339", buy.AssistantId);
        }

        Buy MockBuy()
        {
            return new Buy("Assistant", "Name", "53537339", 7, 1500, MockFunction(), new List<BuyDetail>());
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);
        }
    }
}
