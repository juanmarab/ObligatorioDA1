﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using System;
using System.Collections.Generic;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1Test
{
    [TestClass]
    public class TicketSystemTest
    {

        TicketSystem TicketSystem;

        [TestInitialize()]
        public void Startup()
        {
            TicketSystem = new TicketSystem();
        }

        [TestMethod]
        public void TestAddProducer_OK()
        {
            Producer producer = MockProducer();

            TicketSystem.AddProducer(producer);

            Assert.AreEqual(TicketSystem.Producers[0], producer);
        }

        [TestMethod]
        public void TestAddProducer_ThrowException()
        {
            Producer producer = MockProducer();

            TicketSystem.Producers.Add(producer);

            Assert.ThrowsException<ObjectExistsException>(()=>TicketSystem.AddProducer(producer));
        }

        [TestMethod]
        public void TestProducerExists_Exists()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);

            Producer producer1 = MockProducer();

            Assert.IsTrue(TicketSystem.ProducerAlreadyExists(producer1.Email));
        }

        [TestMethod]
        public void TestProducerExists_NotExists()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);

            Producer producer1 = MockProducer();
            producer1.Email = "email2";

            Assert.IsFalse(TicketSystem.ProducerAlreadyExists(producer1.Email));
        }

        [TestMethod]
        public void TestAddEvent_OK()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);

            Assert.AreEqual(TicketSystem.Events[0], event1);
        }

        [TestMethod]
        public void TestEventExists_Exists()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);

            Assert.IsTrue(TicketSystem.EventAlreadyExists(event1.Name));
        }

        [TestMethod]
        public void TestEventExists_NotExists()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);

            string name = "name2";
            Assert.IsFalse(TicketSystem.EventAlreadyExists(name));
        }

        [TestMethod]
        public void TestFunctionExists_Exists()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);
            
            Function function = MockFunction();
            TicketSystem.Events[0].Functions.Add(function);
            
            Function function2 = MockFunction();

            Assert.IsTrue(TicketSystem.FunctionAlreadyExists(event1, function2));
        }

        [TestMethod]
        public void TestFunctionExists_NotExists()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);
            
            Function function = MockFunction();
            TicketSystem.Events[0].Functions.Add(function);
            
            Function function2 = MockFunction();
            function2.DateStart = Utils.BuildDate("2022-01-21", "11:00");
            Assert.IsFalse(TicketSystem.FunctionAlreadyExists(event1, function2));
        }

        [TestMethod]
        public void TestFunctionExists_NotExistsB()
        {
            Event event1 = MockEvent();
            TicketSystem.AddEvent(event1);

            Function function = MockFunction();
            TicketSystem.Events[0].Functions.Add(function);

            Function function2 = MockFunction();
            function2.DateStart = Utils.BuildDate("2022-01-21", "11:00");
            function2.DateEnd = Utils.BuildDate("2022-01-21", "11:00");

            Assert.IsFalse(TicketSystem.FunctionAlreadyExists(event1, function2));
        }

        [TestMethod]
        public void TestIsPasswordValid_OK()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);
         
            Assert.IsTrue(TicketSystem.IsValidPassword(producer.Email, producer.Password));
        }

        [TestMethod]
        public void TestIsPasswordValid_False()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);

            Assert.IsFalse(TicketSystem.IsValidPassword(producer.Email, "producer98"));
        }

        [TestMethod]
        public void TestIsPasswordValid_FalseA()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);

            Assert.IsFalse(TicketSystem.IsValidPassword("badEmail", "producer98"));
        }

        [TestMethod]
        public void TestGetProducerByEmail()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);

            Assert.AreEqual(TicketSystem.GetProducerByEmail(producer.Email), producer);
        }

        [TestMethod]
        public void TestGetProducerByEmail_ThrowException()
        {
            Producer producer = MockProducer();
            TicketSystem.AddProducer(producer);
            
            Assert.ThrowsException<ObjectNotExistsException>(() => TicketSystem.GetProducerByEmail("wrong@email.com"));
        }

        [TestMethod]
        public void TestGetListEventByProducer_OK()
        {
            Producer producer = MockProducer();
            Event event1 = MockEvent();
            event1.Producer = producer;
            TicketSystem.AddEvent(event1);

            List<Event> expectedList = new List<Event>();
            expectedList.Add(event1); 
            
            Assert.AreEqual(expectedList[0].Name, TicketSystem.GetListEventByProducer(producer)[0].Name);
        }

        [TestMethod]
        public void TestOrderListEventByName_OK()
        {
            Event event1 = MockEvent();
            Event event2 = MockEvent();
            event1.Name = "b";
            event2.Name = "a";
            event1.AddFunction(MockFunction());
            Function function2 = MockFunction();
            event2.AddFunction(function2);
            
            TicketSystem.AddEvent(event1);
            TicketSystem.AddEvent(event2);

            List<Event> expectedList = new List<Event>();
            expectedList.Add(event2);
            expectedList.Add(event1);

            Assert.AreEqual(expectedList[0].Name, TicketSystem.OrderListEventByName()[0].Name);
            Assert.AreEqual(expectedList[1].Name, TicketSystem.OrderListEventByName()[1].Name);
        }

        //[TestMethod]
        //public void TestOrderListEventByDate_OK()
        //{

        //    Function function = MockFunction();
        //    Function function2 = MockFunction();
        //    function2.DateStart = DateTime.Now;

        //    Event event1 = MockEvent();
        //    event1.Name = "b";
        //    event1.Functions.Add(function);
        //    Event event2 = MockEvent();
        //    event2.Functions.Add(function2);
        //    event2.Name = "a";

        //    TicketSystem.AddEvent(event1);
        //    TicketSystem.AddEvent(event2);

        //    List<Event> expectedList = new List<Event>();
        //    expectedList.Add(event1);
        //    expectedList.Add(event2);

        //    Assert.AreEqual(expectedList[0].Name, TicketSystem.OrderListEventByDate()[0].Name);
        //    Assert.AreEqual(expectedList[1].Name, TicketSystem.OrderListEventByDate()[1].Name);
        //}

        [TestMethod]
        public void TestTicketSystemConstructor()
        {
            List<Producer> listProducers = new List<Producer>();
            List<Event> listEvents = new List<Event>();

            TicketSystem ticketSystem = new TicketSystem(listProducers, listEvents);
            Assert.AreEqual(ticketSystem.Producers, listProducers);
            Assert.AreEqual(ticketSystem.Events, listEvents);
        }

        [TestMethod]
        public void TestTicketSystemGetActiveProducer()
        {
            Producer producer = MockProducer();
            TicketSystem ticketSystem = new TicketSystem();
            ticketSystem.ActiveProducer = producer;

            Assert.AreEqual(producer, ticketSystem.ActiveProducer);
        }

        [TestMethod]
        public void TestGenerateBuy()
        {
            Buy expectedBuy = MockBuy();

            Buy actualBuy = TicketSystem.GenerateBuy(expectedBuy.AssistantName, expectedBuy.AssistantLastName, "ID", 7, 1500, expectedBuy.Function, expectedBuy.ListBuyDetails);
            Assert.AreEqual(expectedBuy.AssistantName, actualBuy.AssistantName);
            Assert.AreEqual(expectedBuy.AssistantLastName, actualBuy.AssistantLastName);
            Assert.AreEqual(expectedBuy.QuantityTickets, actualBuy.QuantityTickets);
        }

        [TestMethod]
        public void TestProcessPayment()
        {
            Buy expectedBuy = MockBuy();

            Ticket ticketA = MockTicket();
            ticketA.Name = "A";

            Ticket ticketB = MockTicket();
            ticketA.Name = "B";

            Ticket ticketC = MockTicket();
            ticketA.Name = "C";

            Function function = MockFunction();
            function.Tickets = new List<Ticket> { ticketA, ticketB, ticketC };

            BuyDetail buyDetail = new BuyDetail("ID1", function, ticketA);
            BuyDetail buyDetailB = new BuyDetail("ID2", function, ticketB);
            BuyDetail buyDetailC = new BuyDetail("ID3", function, ticketC);

            List<BuyDetail> buyDetails = new List<BuyDetail> { buyDetail, buyDetailB, buyDetailC};

            expectedBuy.ListBuyDetails = buyDetails;

            Buy generatedBuy = TicketSystem.ProcessPayment(expectedBuy.ListBuyDetails, expectedBuy.AssistantName, expectedBuy.AssistantLastName, "ID", 1500, 7);

            Assert.AreEqual(expectedBuy.AssistantName, generatedBuy.AssistantName);
            Assert.AreEqual(expectedBuy.AssistantLastName, generatedBuy.AssistantLastName);
            Assert.AreEqual(expectedBuy.PriceTotal, generatedBuy.PriceTotal);
        }
        /*
        [TestMethod]
        public void TestProcessPayment_Throw()
        {
            Buy expectedBuy = MockBuy();

            Ticket ticketA = MockTicket();
            ticketA.Name = "A";

            Ticket ticketB = MockTicket();
            ticketA.Name = "B";

            Ticket ticketC = MockTicket();
            ticketA.Name = "C";

            BuyDetail buyDetail = new BuyDetail("ID1", MockFunction(), ticketA);
            BuyDetail buyDetailB = new BuyDetail("ID2", MockFunction(), ticketB);
            BuyDetail buyDetailC = new BuyDetail("ID3", MockFunction(), ticketC);

            List<BuyDetail> buyDetails = new List<BuyDetail> { buyDetail, buyDetailB, buyDetailC };

            expectedBuy.ListBuyDetails = buyDetails;

            Buy generatedBuy = TicketSystem.ProcessPayment(expectedBuy.ListBuyDetails, expectedBuy.AssistantName, expectedBuy.AssistantLastName, "ID", 1500, 7);
        }
        */
        Buy MockBuy()
        {
            return new Buy("Assistant", "Name", "53537339", 7, 1500, MockFunction(), new List<BuyDetail>());
        }

        Producer MockProducer()
        {
            return new Producer("firstName", "lastName", "email@email.com", "password99", new List<Event>());
        }

        Event MockEvent()
        {
            return new Event("name", "description", "category", "image", false, "address", "link", MockProducer(), new List<Ticket>(), new List<Function>());
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-10-01", "10:00"), Utils.BuildDate("2022-10-01", "11:30"), new List<Ticket>(), 150);
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }


    }
}
