﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using ObligatorioDA1.Exceptions;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace ObligatorioDA1Test
{
    [TestClass]
    public class UtilsTest
    {

        [TestMethod]
        public void TestValidateName_OK()
        {
            string firstName = "Nicolas";
            string lastName = "Sogliano";

            Assert.IsTrue(Utils.ValidateName(firstName, lastName));
        }

        [TestMethod]
        public void TestValidateName_False1()
        {
            string firstName = "0Nicolas";
            string lastName = "Sogliano";

            Assert.IsFalse(Utils.ValidateName(firstName, lastName));
        }

        [TestMethod]
        public void TestValidateName_False2()
        {
            string firstName = "Nicolas";
            string lastName = "0Sogliano";

            Assert.IsFalse(Utils.ValidateName(firstName, lastName));
        }

        [TestMethod]
        public void TestValidateEmail_OK()
        {
            string email = "email@email.com";

            Assert.IsTrue(Utils.ValidateEmail(email));
        }

        [TestMethod]
        public void TestValidateEmail_False()
        {
            string email = "email";

            Assert.IsFalse(Utils.ValidateEmail(email));
        }

        [TestMethod]
        public void TestValidatePassword_OK()
        {
            string password = "password123";

            Assert.IsTrue(Utils.ValidatePassword(password));
        }

        [TestMethod]
        public void TestValidatePassword_False()
        {
            string password = "a";

            Assert.IsFalse(Utils.ValidatePassword(password));
        }

        [TestMethod]
        public void TestValidateLink_OK()
        {
            string link = "http://google.com";

            Assert.IsTrue(Utils.ValidateLink(link));
        }

        [TestMethod]
        public void TestValidateLink_False()
        {
            string link = "a";
            Assert.IsFalse(Utils.ValidateLink(link));
        }

        [TestMethod]
        public void TestBuildDate_OK()
        {
            string date = "2022-01-01";
            string hour = "12:00";
            DateTime expectedDateTime = DateTime.ParseExact("2022-01-01 12:00", "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);


            Assert.AreEqual(expectedDateTime, Utils.BuildDate(date, hour));
        }

        [TestMethod]
        public void TestBuildDate_WrongDate()
        {
            string date = "2022-01-";
            string hour = "12:00";

            Assert.ThrowsException<InvalidInputException>(() => Utils.BuildDate(date, hour));
        }

        [TestMethod]
        public void TestBuildDate_WrongHour()
        {
            string date = "2022-01-";
            string hour = "ZZZZ";
            
            Assert.ThrowsException<InvalidInputException>(() => Utils.BuildDate(date, hour));
        }

        [TestMethod]
        public void TestGenerateRandomID()
        {
            string randomId = Utils.GenerateRandomID();

            Assert.AreEqual(10, randomId.Length);
        }
    }
}
