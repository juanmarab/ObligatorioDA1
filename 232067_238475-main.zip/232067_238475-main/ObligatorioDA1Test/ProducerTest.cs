﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using System;
using System.Collections.Generic;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1Test
{
    [TestClass]
    public class ProducerTest
    {

        [TestMethod]
        public void TestCreateProducer_OK()
        {
            string firstName = "firstName";
            string lastName = "lastName";
            string email = "email@email.com";
            string password = "password99";

            Producer expectedProducer = MockProducer();
            Producer actualProducer = new Producer(firstName, lastName, email, password, new List<Event>());

            Assert.AreEqual(expectedProducer.FirstName, actualProducer.FirstName);
            Assert.AreEqual(expectedProducer.LastName, actualProducer.LastName);
            Assert.AreEqual(expectedProducer.Email, actualProducer.Email);
            Assert.AreEqual(expectedProducer.Password, actualProducer.Password);
        }

        public void TestCreateProducer_ThrowException()
        {
            string firstName = "0firstName";
            string lastName = "lastName";
            string email = "email@email.com";
            string password = "password99";

            Assert.ThrowsException<Exception>(() => new Producer(firstName, lastName, email, password, new List<Event>()));
        }

        [TestMethod]
        public void TestProducerInputValidation_OK()
        {
            string firstName = "firstName";
            string lastName = "lastName";
            string email = "email@email.com";
            string password = "password99";

            Assert.IsTrue(Producer.ProducerInputValidation(firstName, lastName, email, password));
        }

        [TestMethod]
        public void TestProducerInputValidation_False1()
        {
            string firstName = "0firstName";
            string lastName = "lastName";
            string email = "email@email.com";
            string password = "password99";

            Assert.ThrowsException<InvalidInputException>(() => Producer.ProducerInputValidation(firstName, lastName, email, password));
        }

        [TestMethod]
        public void TestAddEvent_OK()
        {
            Producer producer = MockProducer();

            Event mockEvent = MockEvent();

            producer.AddEvent(mockEvent);

            Assert.AreEqual(producer.Events[0], mockEvent);
        }

        [TestMethod]
        public void TestProducerEquals_OK()
        {
            Producer producerA = MockProducer();
            Producer producerB = MockProducer();

            Assert.IsTrue(producerA.Equals(producerB));
        }

        [TestMethod]
        public void TestProducerEquals_FalseA()
        {
            Producer producerA = MockProducer();
            Producer producerB = null;

            Assert.IsFalse(producerA.Equals(producerB));
        }

        [TestMethod]
        public void TestProducerEquals_FalseB()
        {
            Producer producer = MockProducer();
            Event event1 = MockEvent();

            Assert.IsFalse(producer.Equals(event1));
        }

        [TestMethod]
        public void TestProducerToString()
        {
            Producer producer = MockProducer();
            string expected = "firstName lastName - email@email.com";
            string actual = producer.ToString();

            Assert.AreEqual(expected,actual);
        }

        Producer MockProducer()
        {
            return new Producer("firstName", "lastName", "email@email.com", "password99", new List<Event>());
        }

        Event MockEvent()
        {
            Producer producerMock = new Producer("Pepito", "Perez", "a@a.com", "asdf1234", new List<Event>());

            Ticket ticketMock = new Ticket("Ticket A", 300, 30, 30);
            Ticket ticketMock2 = new Ticket("Ticket B", 550, 15, 15);
            Ticket ticketMock3 = new Ticket("Ticket C", 150, 30, 30);

            List<Ticket> ticketListMock = new List<Ticket>() { ticketMock, ticketMock2, ticketMock3 };

            Function functionMock = new Function(Utils.BuildDate("2022-01-01", "12:30"), Utils.BuildDate("2022-01-01", "13:30"), new List<Ticket>(), 150);
            Function functionMock2 = new Function(Utils.BuildDate("2022-01-03", "17:00"), Utils.BuildDate("2022-01-03", "18:45"), new List<Ticket>(), 150);

            List<Function> functionListMock = new List<Function>() { functionMock, functionMock2 };

            return new Event("Event Name", "Event description", "Category", "Image", false, "Address", "Link",  producerMock, new List<Ticket>(), functionListMock);

        }
    }
}
