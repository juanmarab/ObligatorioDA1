﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatorioDA1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1Test
{

    [TestClass]
    public class EventTest
    {
        [TestMethod]
        public void TestAddFunction_OK()
        {
            Function function = MockFunction();

            Event event1 = MockEvent();
            event1.AddFunction(function);

            Assert.AreEqual(event1.Functions[0], function);
        }

        [TestMethod]
        public void TestAddFunction_ThrowException()
        {
            Function function = MockFunction();
            Event event1 = MockEvent();

            event1.Functions.Add(function);

            Assert.ThrowsException<ObjectExistsException>(() => event1.AddFunction(function));
        }

        [TestMethod]
        public void TestAddTicket_OK()
        {
            Event event1 = MockEvent();

            Ticket ticket = MockTicket();
            event1.AddTicket(ticket);

            Assert.AreEqual(event1.Tickets[0], ticket);
        }

        [TestMethod]
        public void TestAddTicket_ThrowException()
        {
            Event event1 = MockEvent();
            Ticket ticket = MockTicket();

            event1.Tickets.Add(ticket);

            Assert.ThrowsException<ObjectExistsException>(() => event1.AddTicket(ticket));
        }

        [TestMethod]
        public void CalculateTotalTickets()
        {
            Event event1 = MockEvent();
            Ticket ticket = MockTicket();
            event1.AddTicket(ticket);

            Assert.AreEqual(18900, event1.CalculateTotalTickets());
        }

        [TestMethod]
        public void TestCreateOnlineEvent_OK()
        {
            Event expectedEvent = Event.CreateEvent( "name",  "description",  "category", "image" ,  true, "address", "link", new List<Ticket>(), MockProducer());
            Event actualEvent = Event.CreateEvent("name", "description", "category", "image", true, "address", "link", new List<Ticket>(), MockProducer());

            Assert.AreEqual(expectedEvent, actualEvent);
        }

        [TestMethod]
        public void TestCreatePresentialEvent_OK()
        {
            Event expectedEvent = new Event("name", "description", "category", "image", false, null, "link", MockProducer(), new List<Ticket>(), new List<Function>());
            Event actualEvent = Event.CreateEvent("name", "description", "category", "image", false, null, "link", new List<Ticket>(), MockProducer());
            
            Assert.AreEqual(expectedEvent,actualEvent);
        }

        [TestMethod]
        public void TestEquals_False()
        {
            Event eventA = MockEvent();
            eventA.Link = null;
            Event eventB = MockEvent();
            
            Assert.IsFalse(eventA.Equals(eventB));
        }

        [TestMethod]
        public void TestEquals_FalseB()
        {
            Function function = MockFunction();
            Event eventB = new Event("name", "description", "category", "image", false, null, "link", MockProducer(), new List<Ticket>(), new List<Function>());
            
            Assert.IsFalse(eventB.Equals(function));
        }

        [TestMethod]
        public void TestEquals_FalseC()
        {
            Event eventA = MockEvent();
            eventA.Name = "wrongName";
            Event eventB = MockEvent();
            
            Assert.IsFalse(eventA.Equals(eventB));
        }

        [TestMethod]
        public void TestEquals_FalseD()
        {
            Event eventA = MockEvent();
            eventA.Name = "wrongName";
            eventA.Description = "wrongDescription";
            Event eventB = MockEvent();
            
            Assert.IsFalse(eventA.Equals(eventB));
        }

        [TestMethod]
        public void TestEquals_FalseE()
        {
            Event eventA = MockEvent();
            eventA.Name = "wrongName";
            eventA.Description = "wrongDescription";
            eventA.Address = "wrongAddress";
            Event eventB = MockEvent();
            
            Assert.IsFalse(eventA.Equals(eventB));
        }

        [TestMethod]
        public void TestEquals_FalseF()
        {
            Event eventA = MockEvent();
            eventA.Name = "wrongName";
            eventA.Description = "wrongDescription";
            eventA.Address = "wrongAddress";
            eventA.Link = "wrongLink";
            Event eventB = MockEvent();
            
            Assert.IsFalse(eventA.Equals(eventB));
        }

        [TestMethod]
        public void TestEquals_FalseG()
        {
            Event eventA = MockEvent();
            Event eventB = null;

            Assert.IsFalse(eventA.Equals(eventB));
        }

        /*
        [TestMethod]
        public void TestGetAvailableFunctionsFromNow()
        {
            Event eventA = MockEvent();

            DateTime dateTimeA = Utils.BuildDate("2022-09-09", "12:30");
            DateTime dateTimeB = Utils.BuildDate("2022-09-09", "13:30");

            DateTime dateTimeC = Utils.BuildDate("2022-10-10", "12:30");
            DateTime dateTimeD = Utils.BuildDate("2022-10-10", "12:30");

            Function functionA = MockFunction();
            Function functionB = MockFunction();

            functionA.DateStart = dateTimeA;
            functionA.DateEnd = dateTimeB;

            functionB.DateStart = dateTimeC;
            functionB.DateEnd = dateTimeD;

            List<Function> functions = new List<Function> { functionA, functionB };

            eventA.Functions = functions;

            //Assert.AreEqual(functions, eventA.GetAvailableFunctionsFromNow());
        }*/

        [TestMethod]
        public void CalculateRecentFunctionDate()
        {
            Event eventA = MockEvent();

            DateTime dateTimeA = Utils.BuildDate("2022-09-09", "12:30");
            DateTime dateTimeB = Utils.BuildDate("2022-09-09", "13:30");

            Function functionA = MockFunction();

            functionA.DateStart = dateTimeA;
            functionA.DateEnd = dateTimeB;

            List<Function> functions = new List<Function> { functionA };

            eventA.Functions = functions;

            Assert.AreEqual(dateTimeA, eventA.CalculateRecentFunctionDate());
        }

        [TestMethod]
        public void TestToString()
        {
            Event eventA = MockEvent();

            Assert.AreEqual("name - Functions: 0", eventA.ToString());
        }

        [TestMethod]
        public void TestGetCategory()
        {
            Event eventA = MockEvent();

            Assert.AreEqual("category", eventA.Category);
        }

        [TestMethod]
        public void TestImage()
        {
            Event eventA = MockEvent();

            Assert.AreEqual("image", eventA.Image);
        }

        [TestMethod]
        public void TestIsOnline()
        {
            Event eventA = MockEvent();

            Assert.AreEqual(false, eventA.IsOnline);
        }

        Function MockFunction()
        {
            return new Function(Utils.BuildDate("2022-01-01", "10:00"), Utils.BuildDate("2022-01-01", "11:30"), new List<Ticket>(), 150);
        }

        Event MockEvent()
        {
            return new Event("name", "description", "category", "image", false, "address", "link", MockProducer(), new List<Ticket>(), new List<Function>());
        }

        Producer MockProducer()
        {
            return new Producer("firstName", "lastName", "email@email.com", "password99", new List<Event>());
        }

        Ticket MockTicket()
        {
            return new Ticket("Tribuna Olimpica", 300, 18900, 18900);
        }
    }
}
