﻿namespace ObligatorioDA1.UI
{
    partial class CreateEventScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblName = new System.Windows.Forms.Label();
            this.lblEventAddress = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblImage = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.txtEventName = new System.Windows.Forms.TextBox();
            this.txtEventDescription = new System.Windows.Forms.TextBox();
            this.txtEventAddress = new System.Windows.Forms.TextBox();
            this.lstCategory = new System.Windows.Forms.ComboBox();
            this.btnCreateEvent = new System.Windows.Forms.Button();
            this.btnLoadFile = new System.Windows.Forms.Button();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cbxIsOnline = new System.Windows.Forms.CheckBox();
            this.txtEventLink = new System.Windows.Forms.TextBox();
            this.lblEventLink = new System.Windows.Forms.Label();
            this.lblTicketType = new System.Windows.Forms.Label();
            this.txtTicketTypeName = new System.Windows.Forms.TextBox();
            this.lblNameTicket = new System.Windows.Forms.Label();
            this.txtTicketTypePrice = new System.Windows.Forms.TextBox();
            this.lblPriceTicket = new System.Windows.Forms.Label();
            this.txtTicketTypeQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblListOfTickets = new System.Windows.Forms.Label();
            this.btnCreateTicket = new System.Windows.Forms.Button();
            this.lbxTicketTypes = new System.Windows.Forms.ListBox();
            this.lblExampleInput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(185, 17);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(40, 13);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name";
            // 
            // lblEventAddress
            // 
            this.lblEventAddress.AutoSize = true;
            this.lblEventAddress.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEventAddress.Location = new System.Drawing.Point(172, 188);
            this.lblEventAddress.Name = "lblEventAddress";
            this.lblEventAddress.Size = new System.Drawing.Size(53, 13);
            this.lblEventAddress.TabIndex = 2;
            this.lblEventAddress.Text = "Address";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(158, 41);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(71, 13);
            this.lblDescription.TabIndex = 3;
            this.lblDescription.Text = "Description";
            // 
            // lblImage
            // 
            this.lblImage.AutoSize = true;
            this.lblImage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImage.Location = new System.Drawing.Point(185, 261);
            this.lblImage.Name = "lblImage";
            this.lblImage.Size = new System.Drawing.Size(44, 13);
            this.lblImage.TabIndex = 4;
            this.lblImage.Text = "Image";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(169, 231);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(60, 13);
            this.lblCategory.TabIndex = 6;
            this.lblCategory.Text = "Category";
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(239, 10);
            this.txtEventName.MaxLength = 110;
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(195, 20);
            this.txtEventName.TabIndex = 7;
            // 
            // txtEventDescription
            // 
            this.txtEventDescription.Location = new System.Drawing.Point(239, 38);
            this.txtEventDescription.MaxLength = 250;
            this.txtEventDescription.Multiline = true;
            this.txtEventDescription.Name = "txtEventDescription";
            this.txtEventDescription.Size = new System.Drawing.Size(195, 121);
            this.txtEventDescription.TabIndex = 8;
            // 
            // txtEventAddress
            // 
            this.txtEventAddress.Location = new System.Drawing.Point(239, 185);
            this.txtEventAddress.Name = "txtEventAddress";
            this.txtEventAddress.Size = new System.Drawing.Size(195, 20);
            this.txtEventAddress.TabIndex = 9;
            // 
            // lstCategory
            // 
            this.lstCategory.FormattingEnabled = true;
            this.lstCategory.Location = new System.Drawing.Point(239, 228);
            this.lstCategory.Name = "lstCategory";
            this.lstCategory.Size = new System.Drawing.Size(195, 21);
            this.lstCategory.TabIndex = 13;
            // 
            // btnCreateEvent
            // 
            this.btnCreateEvent.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateEvent.Location = new System.Drawing.Point(239, 282);
            this.btnCreateEvent.Name = "btnCreateEvent";
            this.btnCreateEvent.Size = new System.Drawing.Size(195, 42);
            this.btnCreateEvent.TabIndex = 18;
            this.btnCreateEvent.Text = "Create Event";
            this.btnCreateEvent.UseVisualStyleBackColor = true;
            this.btnCreateEvent.Click += new System.EventHandler(this.btnCreateEvent_Click);
            // 
            // btnLoadFile
            // 
            this.btnLoadFile.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadFile.Location = new System.Drawing.Point(239, 256);
            this.btnLoadFile.Name = "btnLoadFile";
            this.btnLoadFile.Size = new System.Drawing.Size(195, 23);
            this.btnLoadFile.TabIndex = 19;
            this.btnLoadFile.Text = "Upload from computer";
            this.btnLoadFile.UseVisualStyleBackColor = true;
            this.btnLoadFile.Click += new System.EventHandler(this.btnLoadFile_Click);
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.Location = new System.Drawing.Point(158, 327);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lblErrorMessage.TabIndex = 20;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // cbxIsOnline
            // 
            this.cbxIsOnline.AutoSize = true;
            this.cbxIsOnline.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxIsOnline.Location = new System.Drawing.Point(239, 165);
            this.cbxIsOnline.Name = "cbxIsOnline";
            this.cbxIsOnline.Size = new System.Drawing.Size(77, 17);
            this.cbxIsOnline.TabIndex = 30;
            this.cbxIsOnline.Text = "Is Online";
            this.cbxIsOnline.UseVisualStyleBackColor = true;
            this.cbxIsOnline.CheckedChanged += new System.EventHandler(this.cbxIsOnline_CheckedChanged);
            // 
            // txtEventLink
            // 
            this.txtEventLink.Location = new System.Drawing.Point(239, 185);
            this.txtEventLink.MaxLength = 50;
            this.txtEventLink.Name = "txtEventLink";
            this.txtEventLink.Size = new System.Drawing.Size(195, 20);
            this.txtEventLink.TabIndex = 32;
            this.txtEventLink.Visible = false;
            // 
            // lblEventLink
            // 
            this.lblEventLink.AutoSize = true;
            this.lblEventLink.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEventLink.Location = new System.Drawing.Point(195, 188);
            this.lblEventLink.Name = "lblEventLink";
            this.lblEventLink.Size = new System.Drawing.Size(30, 13);
            this.lblEventLink.TabIndex = 31;
            this.lblEventLink.Text = "Link";
            this.lblEventLink.Visible = false;
            // 
            // lblTicketType
            // 
            this.lblTicketType.AutoSize = true;
            this.lblTicketType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicketType.Location = new System.Drawing.Point(580, 10);
            this.lblTicketType.Name = "lblTicketType";
            this.lblTicketType.Size = new System.Drawing.Size(130, 13);
            this.lblTicketType.TabIndex = 33;
            this.lblTicketType.Text = "Create Ticket Type";
            // 
            // txtTicketTypeName
            // 
            this.txtTicketTypeName.Location = new System.Drawing.Point(572, 35);
            this.txtTicketTypeName.Name = "txtTicketTypeName";
            this.txtTicketTypeName.Size = new System.Drawing.Size(138, 20);
            this.txtTicketTypeName.TabIndex = 37;
            // 
            // lblNameTicket
            // 
            this.lblNameTicket.AutoSize = true;
            this.lblNameTicket.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameTicket.Location = new System.Drawing.Point(526, 38);
            this.lblNameTicket.Name = "lblNameTicket";
            this.lblNameTicket.Size = new System.Drawing.Size(40, 13);
            this.lblNameTicket.TabIndex = 36;
            this.lblNameTicket.Text = "Name";
            // 
            // txtTicketTypePrice
            // 
            this.txtTicketTypePrice.Location = new System.Drawing.Point(572, 64);
            this.txtTicketTypePrice.Name = "txtTicketTypePrice";
            this.txtTicketTypePrice.Size = new System.Drawing.Size(138, 20);
            this.txtTicketTypePrice.TabIndex = 39;
            this.txtTicketTypePrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTicketTypePrice_KeyPress);
            // 
            // lblPriceTicket
            // 
            this.lblPriceTicket.AutoSize = true;
            this.lblPriceTicket.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceTicket.Location = new System.Drawing.Point(531, 67);
            this.lblPriceTicket.Name = "lblPriceTicket";
            this.lblPriceTicket.Size = new System.Drawing.Size(35, 13);
            this.lblPriceTicket.TabIndex = 38;
            this.lblPriceTicket.Text = "Price";
            // 
            // txtTicketTypeQuantity
            // 
            this.txtTicketTypeQuantity.Location = new System.Drawing.Point(572, 90);
            this.txtTicketTypeQuantity.Name = "txtTicketTypeQuantity";
            this.txtTicketTypeQuantity.Size = new System.Drawing.Size(138, 20);
            this.txtTicketTypeQuantity.TabIndex = 41;
            this.txtTicketTypeQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTicketTypeQuantity_KeyPress);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(511, 93);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(55, 13);
            this.lblQuantity.TabIndex = 40;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblListOfTickets
            // 
            this.lblListOfTickets.AutoSize = true;
            this.lblListOfTickets.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListOfTickets.Location = new System.Drawing.Point(603, 155);
            this.lblListOfTickets.Name = "lblListOfTickets";
            this.lblListOfTickets.Size = new System.Drawing.Size(78, 13);
            this.lblListOfTickets.TabIndex = 43;
            this.lblListOfTickets.Text = "Ticket Types";
            // 
            // btnCreateTicket
            // 
            this.btnCreateTicket.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnCreateTicket.Location = new System.Drawing.Point(602, 121);
            this.btnCreateTicket.Name = "btnCreateTicket";
            this.btnCreateTicket.Size = new System.Drawing.Size(79, 23);
            this.btnCreateTicket.TabIndex = 42;
            this.btnCreateTicket.Text = "Create Type";
            this.btnCreateTicket.UseVisualStyleBackColor = true;
            this.btnCreateTicket.Click += new System.EventHandler(this.btnCreateTicket_Click);
            // 
            // lbxTicketTypes
            // 
            this.lbxTicketTypes.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxTicketTypes.FormattingEnabled = true;
            this.lbxTicketTypes.Location = new System.Drawing.Point(474, 171);
            this.lbxTicketTypes.Name = "lbxTicketTypes";
            this.lbxTicketTypes.Size = new System.Drawing.Size(344, 147);
            this.lbxTicketTypes.TabIndex = 49;
            // 
            // lblExampleInput
            // 
            this.lblExampleInput.AutoSize = true;
            this.lblExampleInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExampleInput.Location = new System.Drawing.Point(236, 206);
            this.lblExampleInput.Name = "lblExampleInput";
            this.lblExampleInput.Size = new System.Drawing.Size(204, 12);
            this.lblExampleInput.TabIndex = 50;
            this.lblExampleInput.Text = "Must contain http:// Ex: http://www.google.com";
            this.lblExampleInput.Visible = false;
            // 
            // CreateEventScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblExampleInput);
            this.Controls.Add(this.lbxTicketTypes);
            this.Controls.Add(this.lblListOfTickets);
            this.Controls.Add(this.btnCreateTicket);
            this.Controls.Add(this.txtTicketTypeQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtTicketTypePrice);
            this.Controls.Add(this.lblPriceTicket);
            this.Controls.Add(this.txtTicketTypeName);
            this.Controls.Add(this.lblNameTicket);
            this.Controls.Add(this.lblTicketType);
            this.Controls.Add(this.txtEventLink);
            this.Controls.Add(this.lblEventLink);
            this.Controls.Add(this.cbxIsOnline);
            this.Controls.Add(this.lblErrorMessage);
            this.Controls.Add(this.btnLoadFile);
            this.Controls.Add(this.btnCreateEvent);
            this.Controls.Add(this.lstCategory);
            this.Controls.Add(this.txtEventAddress);
            this.Controls.Add(this.txtEventDescription);
            this.Controls.Add(this.txtEventName);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblImage);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblEventAddress);
            this.Controls.Add(this.lblName);
            this.Name = "CreateEventScreen";
            this.Size = new System.Drawing.Size(1008, 513);
            this.Load += new System.EventHandler(this.CreateEventScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblEventAddress;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblImage;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.TextBox txtEventName;
        private System.Windows.Forms.TextBox txtEventDescription;
        private System.Windows.Forms.TextBox txtEventAddress;
        private System.Windows.Forms.ComboBox lstCategory;
        private System.Windows.Forms.Button btnCreateEvent;
        private System.Windows.Forms.Button btnLoadFile;
        private System.Windows.Forms.Label lblErrorMessage;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.CheckBox cbxIsOnline;
        private System.Windows.Forms.TextBox txtEventLink;
        private System.Windows.Forms.Label lblEventLink;
        private System.Windows.Forms.Label lblTicketType;
        private System.Windows.Forms.TextBox txtTicketTypeName;
        private System.Windows.Forms.Label lblNameTicket;
        private System.Windows.Forms.TextBox txtTicketTypePrice;
        private System.Windows.Forms.Label lblPriceTicket;
        private System.Windows.Forms.TextBox txtTicketTypeQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblListOfTickets;
        private System.Windows.Forms.Button btnCreateTicket;
        private System.Windows.Forms.ListBox lbxTicketTypes;
        private System.Windows.Forms.Label lblExampleInput;
    }
}
