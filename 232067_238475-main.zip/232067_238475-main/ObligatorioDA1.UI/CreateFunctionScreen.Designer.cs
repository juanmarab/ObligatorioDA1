﻿namespace ObligatorioDA1.UI
{
    partial class CreateFunctionScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblEvent = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.btnCreateFunction = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtStartDate = new System.Windows.Forms.TextBox();
            this.txtEndDate = new System.Windows.Forms.TextBox();
            this.cbxEvents = new System.Windows.Forms.ComboBox();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.lblStartHour = new System.Windows.Forms.Label();
            this.lblEndHour = new System.Windows.Forms.Label();
            this.txtEndHour = new System.Windows.Forms.TextBox();
            this.txtStartHour = new System.Windows.Forms.TextBox();
            this.lblErrorMessageOne = new System.Windows.Forms.Label();
            this.lblExampleInput = new System.Windows.Forms.Label();
            this.lblExampleHour = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblEvent
            // 
            this.lblEvent.AutoSize = true;
            this.lblEvent.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent.Location = new System.Drawing.Point(336, 11);
            this.lblEvent.Name = "lblEvent";
            this.lblEvent.Size = new System.Drawing.Size(39, 13);
            this.lblEvent.TabIndex = 1;
            this.lblEvent.Text = "Event";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(311, 51);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(66, 13);
            this.lblStartDate.TabIndex = 26;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDate.Location = new System.Drawing.Point(318, 111);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(59, 13);
            this.lblEndDate.TabIndex = 27;
            this.lblEndDate.Text = "End Date";
            // 
            // btnCreateFunction
            // 
            this.btnCreateFunction.Font = new System.Drawing.Font("Verdana", 10F);
            this.btnCreateFunction.Location = new System.Drawing.Point(381, 151);
            this.btnCreateFunction.Name = "btnCreateFunction";
            this.btnCreateFunction.Size = new System.Drawing.Size(223, 51);
            this.btnCreateFunction.TabIndex = 34;
            this.btnCreateFunction.Text = "Create Function";
            this.btnCreateFunction.UseVisualStyleBackColor = true;
            this.btnCreateFunction.Click += new System.EventHandler(this.btnCreateFunction_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtStartDate
            // 
            this.txtStartDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartDate.Location = new System.Drawing.Point(381, 47);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(81, 21);
            this.txtStartDate.TabIndex = 39;
            this.txtStartDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtStartDate_KeyPress);
            // 
            // txtEndDate
            // 
            this.txtEndDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEndDate.Location = new System.Drawing.Point(381, 110);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(81, 21);
            this.txtEndDate.TabIndex = 40;
            this.txtEndDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEndDate_KeyPress);
            // 
            // cbxEvents
            // 
            this.cbxEvents.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxEvents.FormattingEnabled = true;
            this.cbxEvents.Location = new System.Drawing.Point(381, 8);
            this.cbxEvents.Name = "cbxEvents";
            this.cbxEvents.Size = new System.Drawing.Size(223, 21);
            this.cbxEvents.TabIndex = 41;
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Location = new System.Drawing.Point(352, 130);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lblErrorMessage.TabIndex = 42;
            // 
            // lblStartHour
            // 
            this.lblStartHour.AutoSize = true;
            this.lblStartHour.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartHour.Location = new System.Drawing.Point(483, 50);
            this.lblStartHour.Name = "lblStartHour";
            this.lblStartHour.Size = new System.Drawing.Size(34, 13);
            this.lblStartHour.TabIndex = 43;
            this.lblStartHour.Text = "Hour";
            // 
            // lblEndHour
            // 
            this.lblEndHour.AutoSize = true;
            this.lblEndHour.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndHour.Location = new System.Drawing.Point(483, 110);
            this.lblEndHour.Name = "lblEndHour";
            this.lblEndHour.Size = new System.Drawing.Size(34, 13);
            this.lblEndHour.TabIndex = 44;
            this.lblEndHour.Text = "Hour";
            // 
            // txtEndHour
            // 
            this.txtEndHour.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEndHour.Location = new System.Drawing.Point(523, 108);
            this.txtEndHour.Name = "txtEndHour";
            this.txtEndHour.Size = new System.Drawing.Size(81, 21);
            this.txtEndHour.TabIndex = 45;
            this.txtEndHour.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEndHour_KeyPress);
            // 
            // txtStartHour
            // 
            this.txtStartHour.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartHour.Location = new System.Drawing.Point(523, 47);
            this.txtStartHour.Name = "txtStartHour";
            this.txtStartHour.Size = new System.Drawing.Size(81, 21);
            this.txtStartHour.TabIndex = 46;
            this.txtStartHour.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtStartHour_KeyPress);
            // 
            // lblErrorMessageOne
            // 
            this.lblErrorMessageOne.AutoSize = true;
            this.lblErrorMessageOne.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessageOne.Location = new System.Drawing.Point(372, 205);
            this.lblErrorMessageOne.Name = "lblErrorMessageOne";
            this.lblErrorMessageOne.Size = new System.Drawing.Size(0, 13);
            this.lblErrorMessageOne.TabIndex = 47;
            // 
            // lblExampleInput
            // 
            this.lblExampleInput.AutoSize = true;
            this.lblExampleInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExampleInput.Location = new System.Drawing.Point(319, 70);
            this.lblExampleInput.Name = "lblExampleInput";
            this.lblExampleInput.Size = new System.Drawing.Size(145, 12);
            this.lblExampleInput.TabIndex = 49;
            this.lblExampleInput.Text = "yyyy-mm-dd  Example 2022-04-02";
            // 
            // lblExampleHour
            // 
            this.lblExampleHour.AutoSize = true;
            this.lblExampleHour.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExampleHour.Location = new System.Drawing.Point(507, 70);
            this.lblExampleHour.Name = "lblExampleHour";
            this.lblExampleHour.Size = new System.Drawing.Size(97, 12);
            this.lblExampleHour.TabIndex = 50;
            this.lblExampleHour.Text = "hh:mm Example 12:00";
            // 
            // CreateFunctionScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblExampleHour);
            this.Controls.Add(this.lblExampleInput);
            this.Controls.Add(this.lblErrorMessageOne);
            this.Controls.Add(this.txtStartHour);
            this.Controls.Add(this.txtEndHour);
            this.Controls.Add(this.lblEndHour);
            this.Controls.Add(this.lblStartHour);
            this.Controls.Add(this.lblErrorMessage);
            this.Controls.Add(this.cbxEvents);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.btnCreateFunction);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblEvent);
            this.Name = "CreateFunctionScreen";
            this.Size = new System.Drawing.Size(1008, 513);
            this.Load += new System.EventHandler(this.CreateFunctionScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEvent;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Button btnCreateFunction;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtStartDate;
        private System.Windows.Forms.TextBox txtEndDate;
        private System.Windows.Forms.ComboBox cbxEvents;
        private System.Windows.Forms.Label lblErrorMessage;
        private System.Windows.Forms.Label lblStartHour;
        private System.Windows.Forms.Label lblEndHour;
        private System.Windows.Forms.TextBox txtEndHour;
        private System.Windows.Forms.TextBox txtStartHour;
        private System.Windows.Forms.Label lblErrorMessageOne;
        private System.Windows.Forms.Label lblExampleInput;
        private System.Windows.Forms.Label lblExampleHour;
    }
}
