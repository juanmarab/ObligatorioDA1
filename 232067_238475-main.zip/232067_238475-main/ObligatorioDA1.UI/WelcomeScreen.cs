﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class WelcomeScreen : UserControl
    {
        private TicketSystem TicketSystem;

        public WelcomeScreen(TicketSystem ticketSystem)
        {
            InitializeComponent();
            this.TicketSystem = ticketSystem;
            this.TicketSystem.ActiveProducer = null;
        }
    }
}
