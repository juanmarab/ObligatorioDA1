﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class LogInScreen : UserControl
    {

        private TicketSystem TicketSystem;
        private Panel Pnl;
        private Button BtnProducer;
        private bool IsLoginVisible;
        private bool IsRegisterVisible;

        public LogInScreen(TicketSystem ticketSystem, Panel pnl, Button btnProducer, string type)
        {
            this.TicketSystem = ticketSystem;
            this.Pnl = pnl;
            this.BtnProducer = btnProducer;
            InitializeComponent();

            if (type.Equals("login"))
            {
                if (IsRegisterVisible)
                {
                    ChangeRegisterVisibility(false);
                }
                ChangeLoginVisibility(true);
            }
            else
            {
                if (IsLoginVisible)
                {
                    ChangeLoginVisibility(false);
                }
                ChangeRegisterVisibility(true);
            }
        }

        private void ProducerMainScreen_Load(object sender, EventArgs e)
        {
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "firstName", txtFirstName.Text },
                { "lastName", txtLastName.Text },
                { "email", txtEmailRegister.Text },
                { "password", txtPasswordRegister.Text }
            };

            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                try
                {
                    Producer producer = new Producer(
                        txtFirstName.Text,
                        txtLastName.Text,
                        txtEmailRegister.Text,
                        txtPasswordRegister.Text,
                        new List<Event>()
                        );
                    TicketSystem.AddProducer(producer);
                    GreenColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = "Producer '" + producer.FirstName + " " + producer.LastName + "' has been created successfully.";
                }
                catch (Exception ex)
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = ex.Message;
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }

        }

        private List<string> CheckInputErrors(Dictionary<string, string> inputs) {
            List<string> errors = new List<string>();
            foreach (var input in inputs)
            {
                if (string.IsNullOrEmpty(input.Value))
                {
                    errors.Add(input.Key.ToUpper());
                }
            }
            return errors;
        }

        private string BuildErrorMessage(List<string> errors)
        {
            string errorMessage = "Error. Bad inputs entered: ";
            foreach (var error in errors)
            {
                errorMessage += error + " - ";
            }
            return errorMessage;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "email", txtEmailLogin.Text },
                { "password", txtPasswordLogin.Text }
            };

            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                try
                {
                    if (TicketSystem.ProducerAlreadyExists(txtEmailLogin.Text))
                    {
                        if (TicketSystem.IsValidPassword(txtEmailLogin.Text, txtPasswordLogin.Text))
                        {
                            GreenColorLabel(lblErrorMessage);
                            lblErrorMessage.Text = "Welcome to the app.";
                            Pnl.Controls.Clear();
                            BtnProducer.Hide();

                            Producer producer = TicketSystem.GetProducerByEmail(txtEmailLogin.Text);
                            TicketSystem.ActiveProducer = producer;

                            Pnl.Controls.Add(new ProducerScreen(this.TicketSystem, Pnl, BtnProducer));
                        }
                        else
                        {
                            RedColorLabel(lblErrorMessage);
                            lblErrorMessage.Text = "Error. Entered password is not valid.";
                        }
                    }
                    else
                    {
                        RedColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "Error. Producer with email '" + txtEmailLogin + "' does not exist.";
                    }
                }
                catch (Exception)
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = "Error fatal";
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }
        }

        private void RedColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Red;
        }

        private void GreenColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Green;
        }

        private void ChangeLoginVisibility(bool toggle)
        {
            lblLogin.Visible = toggle;

            lblEmailLogin.Visible = toggle;
            txtEmailLogin.Visible = toggle;

            lblPasswordLogin.Visible = toggle;
            txtPasswordLogin.Visible = toggle;

            btnLogin.Visible = toggle;
            IsLoginVisible = toggle;
        }

        private void ChangeRegisterVisibility(bool toggle)
        {
            lblRegister.Visible = toggle;

            lblFirstNameRegister.Visible = toggle;
            txtFirstName.Visible = toggle;

            lblLastNameRegister.Visible = toggle;
            txtLastName.Visible = toggle;

            lblEmailRegister.Visible = toggle;
            txtEmailRegister.Visible = toggle;

            lblPasswordRegister.Visible = toggle;
            txtPasswordRegister.Visible = toggle;

            btnRegister.Visible = toggle;
            IsRegisterVisible = toggle;
        }
    }
}
