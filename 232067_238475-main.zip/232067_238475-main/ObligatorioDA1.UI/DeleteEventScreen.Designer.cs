﻿namespace ObligatorioDA1.UI
{
    partial class DeleteEventScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxMyEvents = new System.Windows.Forms.ComboBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblMyEvents = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbxMyEvents
            // 
            this.cbxMyEvents.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxMyEvents.FormattingEnabled = true;
            this.cbxMyEvents.Location = new System.Drawing.Point(310, 106);
            this.cbxMyEvents.Name = "cbxMyEvents";
            this.cbxMyEvents.Size = new System.Drawing.Size(335, 21);
            this.cbxMyEvents.TabIndex = 0;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(310, 214);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(335, 23);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "Delete Event";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblMyEvents
            // 
            this.lblMyEvents.AutoSize = true;
            this.lblMyEvents.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMyEvents.Location = new System.Drawing.Point(423, 14);
            this.lblMyEvents.Name = "lblMyEvents";
            this.lblMyEvents.Size = new System.Drawing.Size(107, 23);
            this.lblMyEvents.TabIndex = 2;
            this.lblMyEvents.Text = "My Events";
            // 
            // DeleteEventScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblMyEvents);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.cbxMyEvents);
            this.Name = "DeleteEventScreen";
            this.Size = new System.Drawing.Size(1008, 513);
            this.Load += new System.EventHandler(this.DeleteEventScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxMyEvents;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblMyEvents;
    }
}
