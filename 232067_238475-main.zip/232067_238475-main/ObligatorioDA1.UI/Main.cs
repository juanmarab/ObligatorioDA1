﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class Main : Form
    {

        private TicketSystem TicketSystem;
        
        public Main()
        {
            TicketSystem = new TicketSystem();
            InitializeComponent();
            btnImProducer.Show();
        }

        private void btnImProducer_Click(object sender, EventArgs e)
        {
            if (TicketSystem.ActiveProducer == null)
            {
                pnlMain.Controls.Clear();
                pnlMain.Controls.Add(new LogInScreen(TicketSystem, pnlMain, btnImProducer, "login"));
            }
            else
            {
                pnlMain.Controls.Clear();
                pnlMain.Controls.Add(new ProducerScreen(this.TicketSystem, pnlMain, btnImProducer));
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(new CatalogScreen(TicketSystem));
            btnImProducer.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(new LogInScreen(TicketSystem, pnlMain, btnImProducer, "login"));
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(new LogInScreen(TicketSystem, pnlMain, btnImProducer, "register"));
        }
    }
}
