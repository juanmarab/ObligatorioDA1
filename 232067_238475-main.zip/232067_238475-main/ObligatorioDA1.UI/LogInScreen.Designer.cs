﻿namespace ObligatorioDA1.UI
{
    partial class LogInScreen
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblRegister = new System.Windows.Forms.Label();
            this.txtEmailLogin = new System.Windows.Forms.TextBox();
            this.txtPasswordLogin = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtEmailRegister = new System.Windows.Forms.TextBox();
            this.txtPasswordRegister = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblEmailLogin = new System.Windows.Forms.Label();
            this.lblPasswordLogin = new System.Windows.Forms.Label();
            this.lblFirstNameRegister = new System.Windows.Forms.Label();
            this.lblLastNameRegister = new System.Windows.Forms.Label();
            this.lblEmailRegister = new System.Windows.Forms.Label();
            this.lblPasswordRegister = new System.Windows.Forms.Label();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Font = new System.Drawing.Font("Verdana", 15F);
            this.lblLogin.Location = new System.Drawing.Point(490, 10);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(66, 25);
            this.lblLogin.TabIndex = 16;
            this.lblLogin.Text = "Login";
            this.lblLogin.Visible = false;
            // 
            // lblRegister
            // 
            this.lblRegister.AutoSize = true;
            this.lblRegister.Font = new System.Drawing.Font("Verdana", 15F);
            this.lblRegister.Location = new System.Drawing.Point(474, 10);
            this.lblRegister.Name = "lblRegister";
            this.lblRegister.Size = new System.Drawing.Size(95, 25);
            this.lblRegister.TabIndex = 17;
            this.lblRegister.Text = "Register";
            this.lblRegister.Visible = false;
            // 
            // txtEmailLogin
            // 
            this.txtEmailLogin.Location = new System.Drawing.Point(441, 48);
            this.txtEmailLogin.Name = "txtEmailLogin";
            this.txtEmailLogin.Size = new System.Drawing.Size(184, 20);
            this.txtEmailLogin.TabIndex = 18;
            this.txtEmailLogin.Visible = false;
            // 
            // txtPasswordLogin
            // 
            this.txtPasswordLogin.Location = new System.Drawing.Point(441, 79);
            this.txtPasswordLogin.Name = "txtPasswordLogin";
            this.txtPasswordLogin.PasswordChar = '*';
            this.txtPasswordLogin.Size = new System.Drawing.Size(184, 20);
            this.txtPasswordLogin.TabIndex = 19;
            this.txtPasswordLogin.Visible = false;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(441, 52);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(184, 20);
            this.txtFirstName.TabIndex = 20;
            this.txtFirstName.Visible = false;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(441, 78);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(184, 20);
            this.txtLastName.TabIndex = 21;
            this.txtLastName.Visible = false;
            // 
            // txtEmailRegister
            // 
            this.txtEmailRegister.Location = new System.Drawing.Point(441, 104);
            this.txtEmailRegister.Name = "txtEmailRegister";
            this.txtEmailRegister.Size = new System.Drawing.Size(184, 20);
            this.txtEmailRegister.TabIndex = 22;
            this.txtEmailRegister.Visible = false;
            // 
            // txtPasswordRegister
            // 
            this.txtPasswordRegister.Location = new System.Drawing.Point(441, 130);
            this.txtPasswordRegister.Name = "txtPasswordRegister";
            this.txtPasswordRegister.PasswordChar = '*';
            this.txtPasswordRegister.Size = new System.Drawing.Size(184, 20);
            this.txtPasswordRegister.TabIndex = 23;
            this.txtPasswordRegister.Visible = false;
            // 
            // btnRegister
            // 
            this.btnRegister.Font = new System.Drawing.Font("Verdana", 10F);
            this.btnRegister.Location = new System.Drawing.Point(476, 156);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(93, 31);
            this.btnRegister.TabIndex = 24;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Visible = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // lblEmailLogin
            // 
            this.lblEmailLogin.AutoSize = true;
            this.lblEmailLogin.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblEmailLogin.Location = new System.Drawing.Point(389, 51);
            this.lblEmailLogin.Name = "lblEmailLogin";
            this.lblEmailLogin.Size = new System.Drawing.Size(44, 17);
            this.lblEmailLogin.TabIndex = 25;
            this.lblEmailLogin.Text = "Email";
            this.lblEmailLogin.Visible = false;
            // 
            // lblPasswordLogin
            // 
            this.lblPasswordLogin.AutoSize = true;
            this.lblPasswordLogin.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblPasswordLogin.Location = new System.Drawing.Point(360, 79);
            this.lblPasswordLogin.Name = "lblPasswordLogin";
            this.lblPasswordLogin.Size = new System.Drawing.Size(75, 17);
            this.lblPasswordLogin.TabIndex = 26;
            this.lblPasswordLogin.Text = "Password";
            this.lblPasswordLogin.Visible = false;
            // 
            // lblFirstNameRegister
            // 
            this.lblFirstNameRegister.AutoSize = true;
            this.lblFirstNameRegister.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblFirstNameRegister.Location = new System.Drawing.Point(352, 52);
            this.lblFirstNameRegister.Name = "lblFirstNameRegister";
            this.lblFirstNameRegister.Size = new System.Drawing.Size(83, 17);
            this.lblFirstNameRegister.TabIndex = 27;
            this.lblFirstNameRegister.Text = "First Name";
            this.lblFirstNameRegister.Visible = false;
            // 
            // lblLastNameRegister
            // 
            this.lblLastNameRegister.AutoSize = true;
            this.lblLastNameRegister.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblLastNameRegister.Location = new System.Drawing.Point(353, 79);
            this.lblLastNameRegister.Name = "lblLastNameRegister";
            this.lblLastNameRegister.Size = new System.Drawing.Size(82, 17);
            this.lblLastNameRegister.TabIndex = 28;
            this.lblLastNameRegister.Text = "Last Name";
            this.lblLastNameRegister.Visible = false;
            // 
            // lblEmailRegister
            // 
            this.lblEmailRegister.AutoSize = true;
            this.lblEmailRegister.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblEmailRegister.Location = new System.Drawing.Point(391, 107);
            this.lblEmailRegister.Name = "lblEmailRegister";
            this.lblEmailRegister.Size = new System.Drawing.Size(44, 17);
            this.lblEmailRegister.TabIndex = 29;
            this.lblEmailRegister.Text = "Email";
            this.lblEmailRegister.Visible = false;
            // 
            // lblPasswordRegister
            // 
            this.lblPasswordRegister.AutoSize = true;
            this.lblPasswordRegister.Font = new System.Drawing.Font("Verdana", 10F);
            this.lblPasswordRegister.Location = new System.Drawing.Point(360, 131);
            this.lblPasswordRegister.Name = "lblPasswordRegister";
            this.lblPasswordRegister.Size = new System.Drawing.Size(75, 17);
            this.lblPasswordRegister.TabIndex = 30;
            this.lblPasswordRegister.Text = "Password";
            this.lblPasswordRegister.Visible = false;
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.Location = new System.Drawing.Point(389, 193);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lblErrorMessage.TabIndex = 31;
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Verdana", 10F);
            this.btnLogin.Location = new System.Drawing.Point(476, 104);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(93, 31);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Visible = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // LogInScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblErrorMessage);
            this.Controls.Add(this.lblPasswordRegister);
            this.Controls.Add(this.lblEmailRegister);
            this.Controls.Add(this.lblLastNameRegister);
            this.Controls.Add(this.lblFirstNameRegister);
            this.Controls.Add(this.lblPasswordLogin);
            this.Controls.Add(this.lblEmailLogin);
            this.Controls.Add(this.txtPasswordRegister);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtPasswordLogin);
            this.Controls.Add(this.txtEmailLogin);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblRegister);
            this.Controls.Add(this.txtEmailRegister);
            this.Controls.Add(this.btnRegister);
            this.Name = "LogInScreen";
            this.Size = new System.Drawing.Size(1019, 607);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblRegister;
        private System.Windows.Forms.TextBox txtEmailLogin;
        private System.Windows.Forms.TextBox txtPasswordLogin;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtEmailRegister;
        private System.Windows.Forms.TextBox txtPasswordRegister;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label lblEmailLogin;
        private System.Windows.Forms.Label lblPasswordLogin;
        private System.Windows.Forms.Label lblFirstNameRegister;
        private System.Windows.Forms.Label lblLastNameRegister;
        private System.Windows.Forms.Label lblEmailRegister;
        private System.Windows.Forms.Label lblPasswordRegister;
        private System.Windows.Forms.Label lblErrorMessage;
        private System.Windows.Forms.Button btnLogin;
    }
}
