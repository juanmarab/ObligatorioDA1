﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class ProducerScreen : UserControl
    {

        TicketSystem TicketSystem;
        Panel Pnl;
        Button BtnImProducer;

        public ProducerScreen(TicketSystem ticketSystem, Panel pnl, Button imProducer)
        {
            this.TicketSystem = ticketSystem;
            this.Pnl = pnl;
            this.BtnImProducer = imProducer;
            InitializeComponent();
            lblWelcomeMessage.Text += TicketSystem.ActiveProducer.FirstName + " " + TicketSystem.ActiveProducer.LastName;
            BtnImProducer.Hide();
        }

        private void btnViewEvents_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "View Events";
            pnlProducerOptions.Controls.Clear();
            pnlProducerOptions.Controls.Add(new ViewEventsScreen(this.TicketSystem, Pnl));
        }

        private void btnCreateEvent_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Create Event";
            pnlProducerOptions.Controls.Clear();
            pnlProducerOptions.Controls.Add(new CreateEventScreen(this.TicketSystem));
        }

        private void btnCreateFunction_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Create Function";
            pnlProducerOptions.Controls.Clear();
            pnlProducerOptions.Controls.Add(new CreateFunctionScreen(this.TicketSystem));
        }

        private void btnCloseSession_Click(object sender, EventArgs e)
        {
            TicketSystem.ActiveProducer = null;
            BtnImProducer.Show();
            Pnl.Controls.Clear();
            Pnl.Controls.Add(new WelcomeScreen(TicketSystem));
        }

        private void btnDeleteEvent_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Delete Event";
            pnlProducerOptions.Controls.Clear();
            pnlProducerOptions.Controls.Add(new DeleteEventScreen(this.TicketSystem));
        }
    }
}
