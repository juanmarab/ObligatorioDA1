﻿namespace ObligatorioDA1.UI
{
    partial class CatalogScreen
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxEvents = new System.Windows.Forms.ListBox();
            this.btnOrderDate = new System.Windows.Forms.Button();
            this.btnOrderName = new System.Windows.Forms.Button();
            this.lblOrderBy = new System.Windows.Forms.Label();
            this.pnlEventDetail = new System.Windows.Forms.Panel();
            this.btnAddTickets = new System.Windows.Forms.Button();
            this.lbxFunctions = new System.Windows.Forms.ListBox();
            this.lbxTickets = new System.Windows.Forms.ListBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.btnTicketPayment = new System.Windows.Forms.Button();
            this.lstTicketsCart = new System.Windows.Forms.ListBox();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pctEvent = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pctEvent)).BeginInit();
            this.SuspendLayout();
            // 
            // lbxEvents
            // 
            this.lbxEvents.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxEvents.FormattingEnabled = true;
            this.lbxEvents.Location = new System.Drawing.Point(3, 29);
            this.lbxEvents.Name = "lbxEvents";
            this.lbxEvents.Size = new System.Drawing.Size(200, 290);
            this.lbxEvents.TabIndex = 2;
            this.lbxEvents.SelectedIndexChanged += new System.EventHandler(this.lbxMyEvents_SelectedIndexChanged);
            // 
            // btnOrderDate
            // 
            this.btnOrderDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderDate.Location = new System.Drawing.Point(128, 3);
            this.btnOrderDate.Name = "btnOrderDate";
            this.btnOrderDate.Size = new System.Drawing.Size(75, 23);
            this.btnOrderDate.TabIndex = 3;
            this.btnOrderDate.Text = "Date";
            this.btnOrderDate.UseVisualStyleBackColor = true;
            this.btnOrderDate.Click += new System.EventHandler(this.btnOrderDate_Click);
            // 
            // btnOrderName
            // 
            this.btnOrderName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderName.Location = new System.Drawing.Point(52, 3);
            this.btnOrderName.Name = "btnOrderName";
            this.btnOrderName.Size = new System.Drawing.Size(75, 23);
            this.btnOrderName.TabIndex = 4;
            this.btnOrderName.Text = "Name";
            this.btnOrderName.UseVisualStyleBackColor = true;
            this.btnOrderName.Click += new System.EventHandler(this.btnOrderName_Click);
            // 
            // lblOrderBy
            // 
            this.lblOrderBy.AutoSize = true;
            this.lblOrderBy.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderBy.Location = new System.Drawing.Point(6, 8);
            this.lblOrderBy.Name = "lblOrderBy";
            this.lblOrderBy.Size = new System.Drawing.Size(45, 13);
            this.lblOrderBy.TabIndex = 5;
            this.lblOrderBy.Text = "Order:";
            // 
            // pnlEventDetail
            // 
            this.pnlEventDetail.Location = new System.Drawing.Point(3, 325);
            this.pnlEventDetail.Name = "pnlEventDetail";
            this.pnlEventDetail.Size = new System.Drawing.Size(411, 235);
            this.pnlEventDetail.TabIndex = 7;
            // 
            // btnAddTickets
            // 
            this.btnAddTickets.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTickets.Location = new System.Drawing.Point(420, 337);
            this.btnAddTickets.Name = "btnAddTickets";
            this.btnAddTickets.Size = new System.Drawing.Size(128, 31);
            this.btnAddTickets.TabIndex = 8;
            this.btnAddTickets.Text = "Add Tickets";
            this.btnAddTickets.UseVisualStyleBackColor = true;
            this.btnAddTickets.Click += new System.EventHandler(this.btnAddTickets_Click);
            // 
            // lbxFunctions
            // 
            this.lbxFunctions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxFunctions.FormattingEnabled = true;
            this.lbxFunctions.Location = new System.Drawing.Point(420, 29);
            this.lbxFunctions.Name = "lbxFunctions";
            this.lbxFunctions.Size = new System.Drawing.Size(593, 95);
            this.lbxFunctions.TabIndex = 9;
            this.lbxFunctions.SelectedIndexChanged += new System.EventHandler(this.lbxFunctions_SelectedIndexChanged);
            // 
            // lbxTickets
            // 
            this.lbxTickets.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxTickets.FormattingEnabled = true;
            this.lbxTickets.Location = new System.Drawing.Point(420, 157);
            this.lbxTickets.Name = "lbxTickets";
            this.lbxTickets.Size = new System.Drawing.Size(593, 121);
            this.lbxTickets.TabIndex = 10;
            this.lbxTickets.SelectedIndexChanged += new System.EventHandler(this.lbxTickets_SelectedIndexChanged);
            // 
            // txtQuantity
            // 
            this.txtQuantity.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.Location = new System.Drawing.Point(420, 310);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(46, 21);
            this.txtQuantity.TabIndex = 11;
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantity_KeyPress);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Verdana Serif", 10F);
            this.lblQuantity.Location = new System.Drawing.Point(420, 285);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(118, 17);
            this.lblQuantity.TabIndex = 12;
            this.lblQuantity.Text = "Select amount of ";
            // 
            // btnTicketPayment
            // 
            this.btnTicketPayment.Font = new System.Drawing.Font("Verdana", 9F);
            this.btnTicketPayment.Location = new System.Drawing.Point(837, 566);
            this.btnTicketPayment.Name = "btnTicketPayment";
            this.btnTicketPayment.Size = new System.Drawing.Size(176, 31);
            this.btnTicketPayment.TabIndex = 13;
            this.btnTicketPayment.Text = "Ticket Payment";
            this.btnTicketPayment.UseVisualStyleBackColor = true;
            this.btnTicketPayment.Click += new System.EventHandler(this.btnTicketPayment_Click);
            // 
            // lstTicketsCart
            // 
            this.lstTicketsCart.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTicketsCart.FormattingEnabled = true;
            this.lstTicketsCart.Location = new System.Drawing.Point(420, 413);
            this.lstTicketsCart.Name = "lstTicketsCart";
            this.lstTicketsCart.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lstTicketsCart.Size = new System.Drawing.Size(593, 147);
            this.lstTicketsCart.TabIndex = 14;
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.Location = new System.Drawing.Point(552, 346);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(89, 13);
            this.lblErrorMessage.TabIndex = 21;
            this.lblErrorMessage.Text = "Error Message";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana Serif", 10F);
            this.label1.Location = new System.Drawing.Point(420, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 17);
            this.label1.TabIndex = 22;
            this.label1.Text = "Choose a Ticket";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana Serif", 10F);
            this.label2.Location = new System.Drawing.Point(420, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 17);
            this.label2.TabIndex = 23;
            this.label2.Text = "Choose a Function";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana Serif", 10F);
            this.label3.Location = new System.Drawing.Point(420, 393);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 24;
            this.label3.Text = "Ticket Cart";
            // 
            // pctEvent
            // 
            this.pctEvent.Location = new System.Drawing.Point(209, 29);
            this.pctEvent.Name = "pctEvent";
            this.pctEvent.Size = new System.Drawing.Size(205, 290);
            this.pctEvent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctEvent.TabIndex = 25;
            this.pctEvent.TabStop = false;
            // 
            // CatalogScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pctEvent);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblErrorMessage);
            this.Controls.Add(this.lstTicketsCart);
            this.Controls.Add(this.btnTicketPayment);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lbxTickets);
            this.Controls.Add(this.lbxFunctions);
            this.Controls.Add(this.btnAddTickets);
            this.Controls.Add(this.pnlEventDetail);
            this.Controls.Add(this.lblOrderBy);
            this.Controls.Add(this.btnOrderName);
            this.Controls.Add(this.btnOrderDate);
            this.Controls.Add(this.lbxEvents);
            this.Name = "CatalogScreen";
            this.Size = new System.Drawing.Size(1019, 607);
            this.Load += new System.EventHandler(this.CatalogScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctEvent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxEvents;
        private System.Windows.Forms.Button btnOrderDate;
        private System.Windows.Forms.Button btnOrderName;
        private System.Windows.Forms.Label lblOrderBy;
        private System.Windows.Forms.Panel pnlEventDetail;
        private System.Windows.Forms.Button btnAddTickets;
        private System.Windows.Forms.ListBox lbxFunctions;
        private System.Windows.Forms.ListBox lbxTickets;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Button btnTicketPayment;
        private System.Windows.Forms.ListBox lstTicketsCart;
        private System.Windows.Forms.Label lblErrorMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pctEvent;
    }
}
