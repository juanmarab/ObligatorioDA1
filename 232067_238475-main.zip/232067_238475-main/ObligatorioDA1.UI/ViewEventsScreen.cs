﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class ViewEventsScreen : UserControl
    {
        TicketSystem TicketSystem;

        public ViewEventsScreen(TicketSystem ticketSystem, Panel pnl)
        {
            InitializeComponent();
            TicketSystem = ticketSystem;
            pnlEventDetail.Controls.Clear();
        }

        private void lbxMyEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlEventDetail.Controls.Clear();
            Event selectedEvent = lbxMyEvents.SelectedItem as Event;
            pnlEventDetail.Controls.Add(new EventDetail(selectedEvent, pnlEventDetail));
            pctEvent.ImageLocation = selectedEvent.Image;
        }

        private void ViewEventsScreen_Load(object sender, EventArgs e)
        {
            lbxMyEvents.DataSource = TicketSystem.GetListEventByProducer(TicketSystem.ActiveProducer);
        }
    }
}
