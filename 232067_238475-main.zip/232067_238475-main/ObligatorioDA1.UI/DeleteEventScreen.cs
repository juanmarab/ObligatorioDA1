﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class DeleteEventScreen : UserControl
    {
        private TicketSystem TicketSystem;
        public DeleteEventScreen(TicketSystem ticketSystem)
        {
            this.TicketSystem = ticketSystem;
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Event event1 = cbxMyEvents.SelectedItem as Event;
            TicketSystem.Events.Remove(event1);
            
            cbxMyEvents.DataSource = TicketSystem.GetListEventByProducer(TicketSystem.ActiveProducer);
            if (TicketSystem.GetListEventByProducer(TicketSystem.ActiveProducer).Count == 0) cbxMyEvents.Text = "";
        }

        private void DeleteEventScreen_Load(object sender, EventArgs e)
        {
            cbxMyEvents.DataSource = TicketSystem.GetListEventByProducer(TicketSystem.ActiveProducer);
        }
    }
}
