﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1.UI
{
    public partial class CreateFunctionScreen : UserControl
    {
        private TicketSystem TicketSystem;

        public CreateFunctionScreen(TicketSystem ticketSystem)
        {
            this.TicketSystem = ticketSystem;
            InitializeComponent();
        }

        private void btnCreateFunction_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "startDate", txtStartDate.Text },
                { "startHour", txtStartHour.Text },
                { "endDate", txtEndDate.Text },
                { "endHour", txtEndHour.Text },
            };

            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                try
                {
                    GreenColorLabel(lblErrorMessageOne);
                    lblErrorMessageOne.Text = "Function has been created successfully.";

                    Event selectedEvent = cbxEvents.SelectedItem as Event;

                    Function function = Function.CreateFunction(txtStartDate.Text, txtStartHour.Text, txtEndDate.Text, txtEndHour.Text, selectedEvent.Tickets, selectedEvent.CalculateTotalTickets()); 
                    
                    selectedEvent.AddFunction(function);
                    ClearInputs();
                }
                catch (ObjectExistsException ex)
                {
                    RedColorLabel(lblErrorMessageOne);
                    lblErrorMessageOne.Text = ex.Message;
                }
            } 
            else
            {
                RedColorLabel(lblErrorMessageOne);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessageOne.Text = errorMessage;
            }
        }

        private void ClearInputs()
        {
            txtStartDate.Text = "";
            txtStartHour.Text = "";
            txtEndDate.Text = "";
            txtEndHour.Text = "";
        }

        private List<string> CheckInputErrors(Dictionary<string, string> inputs)
        {
            List<string> errors = new List<string>();

            foreach (var input in inputs)
            {
                if (string.IsNullOrEmpty(input.Value))
                {
                    errors.Add(input.Key.ToUpper());
                }

                if(input.Key.Equals("ticketType Quantity"))
                {
                    if (Int32.Parse(input.Value) == 0) errors.Add(input.Key.ToUpper()); 
                }
            }
            return errors;
        }

        private string BuildErrorMessage(List<string> errors)
        {
            string errorMessage = "The following fields must be filled:  ";
            foreach (var error in errors)
            {
                errorMessage += error + " - ";
            }
            return errorMessage;
        }

        private void RedColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Red;
        }
        private void GreenColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Green;
        }

        private void txtFieldHourFormat(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ':'))
            {
                e.Handled = true;
            }
        }

        private void txtFieldDateFormat(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }
        }

        private void txtStartHour_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldHourFormat(sender, e);
        }
        
        private void txtEndHour_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldHourFormat(sender, e);
        }

        private void txtStartDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldDateFormat(sender,e);
        }

        private void txtEndDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldDateFormat(sender, e);
        }

        private void CreateFunctionScreen_Load(object sender, EventArgs e)
        {
            cbxEvents.DataSource = TicketSystem.GetListEventByProducer(TicketSystem.ActiveProducer);
        }
    }
}
