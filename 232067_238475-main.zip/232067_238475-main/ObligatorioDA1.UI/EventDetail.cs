﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class EventDetail : UserControl
    {

        private Event e;

        public EventDetail(Event e, Panel pnlEventDetail)
        {
            this.e = e;
            InitializeComponent();
            LoadFields();
        }

        private void LoadFields()
        {
            lblDetailName.Text = e.Name;
            lblDetailDescription.Text = e.Description;
            lblDetailAddress.Text = e.Address;
            lblDetailCategory.Text = e.Category;
            lblDetailProducer.Text = e.Producer.ToString();
            lstDetailFunctions.DataSource = e.Functions;
            lstTicketTypes.DataSource = e.Tickets;
        }
    }
}
