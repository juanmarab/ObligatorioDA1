﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class CatalogScreen : UserControl
    {

        private TicketSystem TicketSystem;
        private int quantityAccumulator;
        private List<BuyDetail> BuyDetailTicketAccumulator;
        private int position = 0;

        public CatalogScreen(TicketSystem ticketSystem)
        {
            TicketSystem = ticketSystem;
            InitializeComponent();
        }

        private void CatalogScreen_Load(object sender, EventArgs e)
        {
            this.BuyDetailTicketAccumulator = new List<BuyDetail>();
            lbxEvents.DataSource = TicketSystem.GetAvailableEventsFromNow();
        }

        private void lbxMyEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlEventDetail.Controls.Clear();
            Event selectedEvent = lbxEvents.SelectedItem as Event;
            pnlEventDetail.Controls.Add(new EventDetail(selectedEvent, pnlEventDetail));

            lbxFunctions.DataSource = selectedEvent.GetAvailableFunctionsFromNow();
            
            pctEvent.ImageLocation = selectedEvent.Image;
        }

        private void lbxFunctions_SelectedIndexChanged(object sender, EventArgs e)
        {
            Event selectedEvent = lbxEvents.SelectedItem as Event;
            lbxFunctions.DataSource = selectedEvent.Functions;
            Function selectedFunction = lbxFunctions.SelectedItem as Function;
            Console.WriteLine(selectedEvent.ToString());
            Console.WriteLine(selectedFunction.ToString());
            lbxTickets.DataSource = selectedFunction.Tickets;
            Console.WriteLine(selectedFunction.ToString());
        }

        private void lbxTickets_SelectedIndexChanged(object sender, EventArgs e)
        {
            Function selectedFunction = lbxFunctions.SelectedItem as Function;
            lbxTickets.DataSource = selectedFunction.Tickets;

            Ticket selectedTicket = lbxTickets.SelectedItem as Ticket;

            lblQuantity.Text = "Select amount of '" + selectedTicket.Name + "' tickets.";
        }


        private List<string> CheckInputErrors(Dictionary<string, string> inputs)
        {
            List<string> errors = new List<string>();
            foreach (var input in inputs)
            {
                if (string.IsNullOrEmpty(input.Value))
                {
                    errors.Add(input.Key.ToUpper());
                }
            }
            return errors;
        }

        private void btnOrderName_Click(object sender, EventArgs e)
        {
            lbxEvents.DataSource = TicketSystem.OrderListEventByName();
        }

        private void btnOrderDate_Click(object sender, EventArgs e)
        {
            //lbxEvents.DataSource = TicketSystem.OrderEventListByDate(); Pendiente de implementacion
        }

        private string BuildErrorMessage(List<string> errors)
        {
            string errorMessage = "Error. Bad inputs entered: ";
            foreach (var error in errors)
            {
                errorMessage += error + " - ";
            }
            return errorMessage;
        }

        private void RedColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Red;
        }
        private void GreenColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Green;
        }

        private void txtFieldOnlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyNumbers(sender, e);
        }

        private void btnTicketPayment_Click(object sender, EventArgs e)
        {
            Form form = new PaymentWindow(BuyDetailTicketAccumulator);
            position = 0;
            BuyDetailTicketAccumulator = new List<BuyDetail>();
            form.Show();
        }

        private void btnAddTickets_Click(object sender, EventArgs e)
        {
            Function selectedFunction = lbxFunctions.SelectedItem as Function;
            Ticket selectedTicket = lbxTickets.SelectedItem as Ticket;
            int quantity = 0;
            
            var inputs = new Dictionary<string, string>() {
                { "quantity", txtQuantity.Text }
            };

            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                quantity = Int32.Parse(txtQuantity.Text);

                if (quantityAccumulator+quantity <= 10)
                {
                    quantityAccumulator += quantity;
                    try
                    {
                        
                        List<BuyDetail> specificBuyDetail = BuyDetail.GenerateTickets(selectedFunction, selectedTicket, quantity);
                        
                        foreach(BuyDetail detail in specificBuyDetail)
                        {
                            BuyDetailTicketAccumulator.Add(detail);
                        }

                        for (int i = 0; i < quantity ; i++)
                        {
                            lstTicketsCart.Items.Add(BuyDetailTicketAccumulator[position]);
                            position++;
                        }

                        GreenColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "Added " + txtQuantity.Text + " tickets of '" + selectedTicket.Name + "'";
                    }
                    catch (Exception)
                    {
                        RedColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "Error. Could not add tickets.";
                    }
                }
                else
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = "Error. You only can only buy 10 tickets per purchase.";
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }
        }
    }
}
