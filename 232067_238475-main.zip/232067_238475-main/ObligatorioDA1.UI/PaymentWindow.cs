﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class PaymentWindow : Form
    {
        public PaymentWindow(List<BuyDetail> BuyDetailTicketAccumulator)
        {
            InitializeComponent();
            pnlPaymentScreen.Controls.Add(new TicketPaymentScreen(BuyDetailTicketAccumulator));
        }
    }
}
