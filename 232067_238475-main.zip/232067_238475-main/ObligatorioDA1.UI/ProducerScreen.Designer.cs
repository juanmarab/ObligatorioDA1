﻿namespace ObligatorioDA1.UI
{
    partial class ProducerScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlProducerOptions = new System.Windows.Forms.Panel();
            this.lblWelcomeMessage = new System.Windows.Forms.Label();
            this.btnViewEvents = new System.Windows.Forms.Button();
            this.btnCloseSession = new System.Windows.Forms.Button();
            this.btnCreateFunction = new System.Windows.Forms.Button();
            this.btnCreateEvent = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnDeleteEvent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pnlProducerOptions
            // 
            this.pnlProducerOptions.Location = new System.Drawing.Point(7, 46);
            this.pnlProducerOptions.Name = "pnlProducerOptions";
            this.pnlProducerOptions.Size = new System.Drawing.Size(1008, 513);
            this.pnlProducerOptions.TabIndex = 4;
            // 
            // lblWelcomeMessage
            // 
            this.lblWelcomeMessage.AutoSize = true;
            this.lblWelcomeMessage.Font = new System.Drawing.Font("Verdana", 14F);
            this.lblWelcomeMessage.Location = new System.Drawing.Point(3, 0);
            this.lblWelcomeMessage.Name = "lblWelcomeMessage";
            this.lblWelcomeMessage.Size = new System.Drawing.Size(110, 23);
            this.lblWelcomeMessage.TabIndex = 7;
            this.lblWelcomeMessage.Text = "Welcome, ";
            // 
            // btnViewEvents
            // 
            this.btnViewEvents.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewEvents.Location = new System.Drawing.Point(451, 565);
            this.btnViewEvents.Name = "btnViewEvents";
            this.btnViewEvents.Size = new System.Drawing.Size(110, 39);
            this.btnViewEvents.TabIndex = 16;
            this.btnViewEvents.Text = "View Events";
            this.btnViewEvents.UseVisualStyleBackColor = true;
            this.btnViewEvents.Click += new System.EventHandler(this.btnViewEvents_Click);
            // 
            // btnCloseSession
            // 
            this.btnCloseSession.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseSession.Location = new System.Drawing.Point(918, 565);
            this.btnCloseSession.Name = "btnCloseSession";
            this.btnCloseSession.Size = new System.Drawing.Size(97, 39);
            this.btnCloseSession.TabIndex = 15;
            this.btnCloseSession.Text = "Close Session";
            this.btnCloseSession.UseVisualStyleBackColor = true;
            this.btnCloseSession.Click += new System.EventHandler(this.btnCloseSession_Click);
            // 
            // btnCreateFunction
            // 
            this.btnCreateFunction.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateFunction.Location = new System.Drawing.Point(683, 565);
            this.btnCreateFunction.Name = "btnCreateFunction";
            this.btnCreateFunction.Size = new System.Drawing.Size(110, 39);
            this.btnCreateFunction.TabIndex = 14;
            this.btnCreateFunction.Text = "Create Function";
            this.btnCreateFunction.UseVisualStyleBackColor = true;
            this.btnCreateFunction.Click += new System.EventHandler(this.btnCreateFunction_Click);
            // 
            // btnCreateEvent
            // 
            this.btnCreateEvent.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateEvent.Location = new System.Drawing.Point(335, 565);
            this.btnCreateEvent.Name = "btnCreateEvent";
            this.btnCreateEvent.Size = new System.Drawing.Size(110, 39);
            this.btnCreateEvent.TabIndex = 13;
            this.btnCreateEvent.Text = "Create Event";
            this.btnCreateEvent.UseVisualStyleBackColor = true;
            this.btnCreateEvent.Click += new System.EventHandler(this.btnCreateEvent_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(300, 18);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(0, 25);
            this.lblTitle.TabIndex = 17;
            // 
            // btnDeleteEvent
            // 
            this.btnDeleteEvent.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnDeleteEvent.Location = new System.Drawing.Point(567, 565);
            this.btnDeleteEvent.Name = "btnDeleteEvent";
            this.btnDeleteEvent.Size = new System.Drawing.Size(110, 39);
            this.btnDeleteEvent.TabIndex = 18;
            this.btnDeleteEvent.Text = "Delete Event";
            this.btnDeleteEvent.UseVisualStyleBackColor = true;
            this.btnDeleteEvent.Click += new System.EventHandler(this.btnDeleteEvent_Click);
            // 
            // ProducerScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCreateEvent);
            this.Controls.Add(this.btnDeleteEvent);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnCloseSession);
            this.Controls.Add(this.btnViewEvents);
            this.Controls.Add(this.btnCreateFunction);
            this.Controls.Add(this.lblWelcomeMessage);
            this.Controls.Add(this.pnlProducerOptions);
            this.Name = "ProducerScreen";
            this.Size = new System.Drawing.Size(1019, 607);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnlProducerOptions;
        private System.Windows.Forms.Label lblWelcomeMessage;
        private System.Windows.Forms.Button btnViewEvents;
        private System.Windows.Forms.Button btnCloseSession;
        private System.Windows.Forms.Button btnCreateFunction;
        private System.Windows.Forms.Button btnCreateEvent;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnDeleteEvent;
    }
}
