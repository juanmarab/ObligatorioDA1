﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class TicketPaymentScreen : UserControl
    {
        private List<BuyDetail> BuyDetailList;

        public TicketPaymentScreen(List<BuyDetail> buyDetailList)
        {
            InitializeComponent();
            BuyDetailList = buyDetailList;
        }

        private void txtFieldOnlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtFieldOnlyLetters(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyLetters(sender, e);
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyLetters(sender, e);
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyNumbers(sender, e);
        }

        private void TicketPaymentScreen_Load(object sender, EventArgs e)
        {
            lstTicketsCart.DataSource = BuyDetailList;
            lblQuantity.Text = BuyDetailList.Count.ToString();
            lblTotalPrice.Text = BuyDetail.CalculateTotalCost(BuyDetailList).ToString();
        }

        private void btnBuyTickets_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "name", txtName.Text },
                { "lastName", txtLastName.Text },
                { "id", txtID.Text },
            };

            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                try
                {
                    List<BuyDetail> list = (List<BuyDetail>)lstTicketsCart.DataSource;
                    Buy buy = TicketSystem.ProcessPayment(list, txtName.Text, txtLastName.Text, txtID.Text, Int32.Parse(lblTotalPrice.Text), list.Count);

                    GreenColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = "Purchase made successfully.";

                    lblDetail.Text = buy.ToString();

                    ClearInputs();
                }
                catch (Exception ex)
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = "Could not make purchase.";
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }
        }

        private void ClearInputs()
        {
            txtName.Text = "";
            txtLastName.Text = "";
            txtID.Text = "";
            lstTicketsCart.DataSource = null;
        }

        private List<string> CheckInputErrors(Dictionary<string, string> inputs)
        {
            List<string> errors = new List<string>();

            foreach (var input in inputs)
            {
                if (string.IsNullOrEmpty(input.Value))
                {
                    errors.Add(input.Key.ToUpper());
                }
            }
            return errors;
        }

        private string BuildErrorMessage(List<string> errors)
        {
            string errorMessage = "The following fields must be filled:  ";
            foreach (var error in errors)
            {
                errorMessage += error + " - ";
            }
            return errorMessage;
        }

        private void RedColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Red;
        }
        private void GreenColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Green;
        }
    }
}
