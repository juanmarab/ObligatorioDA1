﻿namespace ObligatorioDA1.UI
{
    partial class EventDetail
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDetailName = new System.Windows.Forms.Label();
            this.lblDetailDescription = new System.Windows.Forms.Label();
            this.lblDetailAddress = new System.Windows.Forms.Label();
            this.lblDetailCategory = new System.Windows.Forms.Label();
            this.lblDetailProducer = new System.Windows.Forms.Label();
            this.lstDetailFunctions = new System.Windows.Forms.ListBox();
            this.lblTicketTypes = new System.Windows.Forms.Label();
            this.lstTicketTypes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Description:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Category:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(30, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Producer:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 168);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Functions:";
            // 
            // lblDetailName
            // 
            this.lblDetailName.AutoSize = true;
            this.lblDetailName.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailName.Location = new System.Drawing.Point(107, 7);
            this.lblDetailName.Name = "lblDetailName";
            this.lblDetailName.Size = new System.Drawing.Size(49, 16);
            this.lblDetailName.TabIndex = 6;
            this.lblDetailName.Text = "Name:";
            // 
            // lblDetailDescription
            // 
            this.lblDetailDescription.AutoSize = true;
            this.lblDetailDescription.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailDescription.Location = new System.Drawing.Point(107, 28);
            this.lblDetailDescription.Name = "lblDetailDescription";
            this.lblDetailDescription.Size = new System.Drawing.Size(49, 16);
            this.lblDetailDescription.TabIndex = 7;
            this.lblDetailDescription.Text = "Name:";
            // 
            // lblDetailAddress
            // 
            this.lblDetailAddress.AutoSize = true;
            this.lblDetailAddress.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailAddress.Location = new System.Drawing.Point(107, 49);
            this.lblDetailAddress.Name = "lblDetailAddress";
            this.lblDetailAddress.Size = new System.Drawing.Size(49, 16);
            this.lblDetailAddress.TabIndex = 8;
            this.lblDetailAddress.Text = "Name:";
            // 
            // lblDetailCategory
            // 
            this.lblDetailCategory.AutoSize = true;
            this.lblDetailCategory.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailCategory.Location = new System.Drawing.Point(107, 71);
            this.lblDetailCategory.Name = "lblDetailCategory";
            this.lblDetailCategory.Size = new System.Drawing.Size(49, 16);
            this.lblDetailCategory.TabIndex = 9;
            this.lblDetailCategory.Text = "Name:";
            // 
            // lblDetailProducer
            // 
            this.lblDetailProducer.AutoSize = true;
            this.lblDetailProducer.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailProducer.Location = new System.Drawing.Point(107, 93);
            this.lblDetailProducer.Name = "lblDetailProducer";
            this.lblDetailProducer.Size = new System.Drawing.Size(49, 16);
            this.lblDetailProducer.TabIndex = 10;
            this.lblDetailProducer.Text = "Name:";
            // 
            // lstDetailFunctions
            // 
            this.lstDetailFunctions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDetailFunctions.FormattingEnabled = true;
            this.lstDetailFunctions.Location = new System.Drawing.Point(103, 178);
            this.lstDetailFunctions.Name = "lstDetailFunctions";
            this.lstDetailFunctions.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lstDetailFunctions.Size = new System.Drawing.Size(307, 56);
            this.lstDetailFunctions.TabIndex = 11;
            // 
            // lblTicketTypes
            // 
            this.lblTicketTypes.AutoSize = true;
            this.lblTicketTypes.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.lblTicketTypes.Location = new System.Drawing.Point(2, 114);
            this.lblTicketTypes.Name = "lblTicketTypes";
            this.lblTicketTypes.Size = new System.Drawing.Size(92, 16);
            this.lblTicketTypes.TabIndex = 12;
            this.lblTicketTypes.Text = "Ticket Types";
            // 
            // lstTicketTypes
            // 
            this.lstTicketTypes.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTicketTypes.FormattingEnabled = true;
            this.lstTicketTypes.Location = new System.Drawing.Point(103, 115);
            this.lstTicketTypes.Name = "lstTicketTypes";
            this.lstTicketTypes.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lstTicketTypes.Size = new System.Drawing.Size(307, 56);
            this.lstTicketTypes.TabIndex = 13;
            // 
            // EventDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lstTicketTypes);
            this.Controls.Add(this.lblTicketTypes);
            this.Controls.Add(this.lstDetailFunctions);
            this.Controls.Add(this.lblDetailProducer);
            this.Controls.Add(this.lblDetailCategory);
            this.Controls.Add(this.lblDetailAddress);
            this.Controls.Add(this.lblDetailDescription);
            this.Controls.Add(this.lblDetailName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EventDetail";
            this.Size = new System.Drawing.Size(415, 243);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblDetailName;
        private System.Windows.Forms.Label lblDetailDescription;
        private System.Windows.Forms.Label lblDetailAddress;
        private System.Windows.Forms.Label lblDetailCategory;
        private System.Windows.Forms.Label lblDetailProducer;
        private System.Windows.Forms.ListBox lstDetailFunctions;
        private System.Windows.Forms.Label lblTicketTypes;
        private System.Windows.Forms.ListBox lstTicketTypes;
    }
}
