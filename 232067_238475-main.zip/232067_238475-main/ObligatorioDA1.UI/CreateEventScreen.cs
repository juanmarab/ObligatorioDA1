﻿using Microsoft.IdentityModel.Protocols.WSIdentity;
using ObligatorioDA1.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObligatorioDA1.UI
{
    public partial class CreateEventScreen : UserControl
    {
        private TicketSystem TicketSystem;

        private static List<string> Categories = new List<string> { "Conferences", "Courses", "Football", "Music", "Sports", "Theatre", "Others" };

        private OpenFileDialog OpenDialog;

        private string EventImageLocation;

        private List<Ticket> EventTicketList;

        public CreateEventScreen(TicketSystem ticketSystem)
        {
            this.TicketSystem = ticketSystem;
            InitializeComponent();
        }

        private void btnCreateEvent_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "name", txtEventName.Text },
                { "description", txtEventDescription.Text },
                { "category", Categories[lstCategory.SelectedIndex]},
                { "image", btnLoadFile.Text},
                { "ticketType Quantity", (lbxTicketTypes.Items.Count).ToString()}
            };

            Console.WriteLine((lbxTicketTypes.Items.Count).ToString());

            if (cbxIsOnline.Checked)
            {
                inputs.Add("link", txtEventLink.Text);
            }
            else
            {
                inputs.Add("address", txtEventAddress.Text);
            }
            List<string> inputErrors = CheckInputErrors(inputs);
            if (inputErrors.Count == 0)
            {
                try
                {
                    if (!TicketSystem.EventAlreadyExists(txtEventName.Text))
                    {
                        Event newEvent = Event.CreateEvent(txtEventName.Text, txtEventDescription.Text,
                            Categories[lstCategory.SelectedIndex], EventImageLocation, cbxIsOnline.Checked,
                            txtEventAddress.Text, txtEventLink.Text, EventTicketList, TicketSystem.ActiveProducer);
                        TicketSystem.AddEvent(newEvent);
                        GreenColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "Event '" + txtEventName.Text + "' has been created successfully.";
                        ClearEventInputs();
                    }
                    else
                    {
                        throw new ObjectExistsException("Event");
                    }
                }
                catch (ObjectExistsException objectException)
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = objectException.Message;
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }
        }

        private void ClearEventInputs()
        {
            lbxTicketTypes.Items.Clear();
            EventTicketList = new List<Ticket>();
            txtEventName.Text = "";
            txtEventDescription.Text = "";
            txtEventLink.Text = "";
            txtEventAddress.Text = "";
            EventImageLocation = null;
            cbxIsOnline.Checked = false;
        }

        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            string imageLocation = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = dialog.FileName;
                }

                EventImageLocation = imageLocation;
            }
            catch (Exception)
            {
                lblErrorMessage.Text = "Error loading image.";
            }
        }

        private List<string> CheckInputErrors(Dictionary<string, string> inputs)
        {
            List<string> errors = new List<string>();
            foreach (var input in inputs)
            {
                if (string.IsNullOrEmpty(input.Value))
                {
                    errors.Add(input.Key.ToUpper());
                }

                if (input.Key.Equals("ticketType Quantity"))
                {
                    if(input.Value.Equals("0")) errors.Add(input.Key.ToUpper());
                }

                if (input.Key.Equals("link"))
                {
                    if (!Utils.ValidateLink(input.Value)) errors.Add(input.Key.ToUpper());
                }
            }
            return errors;
        }

        private string BuildErrorMessage(List<string> errors)
        {
            string errorMessage = "Error. Bad inputs entered: ";
            foreach (var error in errors)
            {
                errorMessage += error + " - ";
            }
            return errorMessage;
        }

        private void btnCreateTicket_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
            var inputs = new Dictionary<string, string>() {
                { "name", txtTicketTypeName.Text },
                { "price", txtTicketTypePrice.Text },
                { "quantity", txtTicketTypeQuantity.Text },
            };


            List<string> inputErrors = CheckInputErrors(inputs);

            if (inputErrors.Count == 0)
            {
                try
                {
                    Ticket ticket = new Ticket(
                        txtTicketTypeName.Text,
                        Int32.Parse(txtTicketTypePrice.Text),
                        Int32.Parse(txtTicketTypeQuantity.Text),
                        Int32.Parse(txtTicketTypeQuantity.Text)
                        );

                    if (!TicketTypeAlreadyExists(ticket))
                    {
                        EventTicketList.Add(ticket);
                        GreenColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "Ticket '" + txtTicketTypeName.Text + "' has been created successfully.";

                        lbxTicketTypes.Items.Add(ticket);
                        ClearTicketTypeInputs();
                    }
                    else
                    {
                        RedColorLabel(lblErrorMessage);
                        lblErrorMessage.Text = "ERROR - Ticket '" + txtTicketTypeName.Text + "' already exists.";
                    }

                }
                catch (ObjectExistsException objectExists)
                {
                    RedColorLabel(lblErrorMessage);
                    lblErrorMessage.Text = objectExists.Message;
                }
            }
            else
            {
                RedColorLabel(lblErrorMessage);
                string errorMessage = BuildErrorMessage(inputErrors);
                lblErrorMessage.Text = errorMessage;
            }
        }

        private void ClearTicketTypeInputs()
        {
            txtTicketTypeName.Text = "";
            txtTicketTypePrice.Text = "";
            txtTicketTypeQuantity.Text = "";
        }

        private bool TicketTypeAlreadyExists(Ticket ticket)
        {
            foreach (Ticket t in EventTicketList)
            {
                if (t.Name.Equals(ticket.Name))
                {
                    return true;
                }
            }
            return false;
        }

        private void cbxIsOnline_CheckedChanged(object sender, EventArgs e)
        {
            lblEventLink.Visible = !lblEventLink.Visible;
            txtEventLink.Visible = !txtEventLink.Visible;
            lblExampleInput.Visible = !lblExampleInput.Visible;

            lblEventAddress.Visible = !lblEventAddress.Visible;
            txtEventAddress.Visible = !txtEventAddress.Visible;
        }

        private void txtFieldOnlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtTicketTypePrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyNumbers(sender, e);
        }

        private void txtTicketTypeQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtFieldOnlyNumbers(sender, e);
        }

        private void CreateEventScreen_Load(object sender, EventArgs e)
        {
            this.EventTicketList = new List<Ticket>();
            lstCategory.DataSource = Categories;
            OpenDialog = new OpenFileDialog();
            OpenDialog.Title = "Select Event Image";
            OpenDialog.Filter = "";
        }

        private void RedColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Red;
        }
        private void GreenColorLabel(Label lblError)
        {
            lblError.ForeColor = Color.Green;
        }
    }
}
