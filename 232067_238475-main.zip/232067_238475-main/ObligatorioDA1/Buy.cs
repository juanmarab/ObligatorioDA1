﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1
{
    public class Buy
    {
        public Buy(string assistantName, string assistantLastName, string assistantID, int quantityTickets, double priceTotal,  Function function,  List<BuyDetail> listBuyDetails)
        {
            AssistantName = assistantName;
            AssistantLastName = assistantLastName;
            AssistantId = assistantID;
            QuantityTickets = quantityTickets;
            PriceTotal = priceTotal;
            Function = function;
            ListBuyDetails = listBuyDetails;
        }

        public string AssistantName { get; set; }

        public string AssistantLastName { get; set; }

        public string AssistantId { get; set; }

        public int QuantityTickets { get; set; }

        public double PriceTotal { get; set; }

        public Function Function { get; set; }

        public List<BuyDetail> ListBuyDetails { get; set; }

        public override string ToString()
        {
            string text = "";
            List<Ticket> listOfDistinctTickets = new List<Ticket>();
            foreach (BuyDetail buyDetail in ListBuyDetails)
            {
                if (!listOfDistinctTickets.Contains(buyDetail.TicketBought))
                {
                    listOfDistinctTickets.Add(buyDetail.TicketBought);
                }
            }

            foreach (Ticket ticket in listOfDistinctTickets)
            {
                text += ticket.Name + ":\n";
                foreach (BuyDetail buyDetail in ListBuyDetails)
                {
                    if (buyDetail.TicketBought.Name.Equals(ticket.Name))
                    {
                        text += " - " + buyDetail.TicketId + " - " + AssistantName + " " + AssistantLastName + " - " + AssistantId + "\n";
                    }
                }
                text += "\n";
            }
            
            return text;
        }
    }
}
