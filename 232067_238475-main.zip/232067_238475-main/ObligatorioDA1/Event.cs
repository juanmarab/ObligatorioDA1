﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1
{
    public class Event
    {
        public Event(string name, string description, string category, string image, bool isOnline, string address, string link, Producer producer, List<Ticket> tickets, List<Function> functions)
        {
            Name = name;
            Description = description;
            Category = category;
            Image = image;
            IsOnline = isOnline;
            Address = address;
            Link = link;
            Tickets = tickets;
            Producer = producer;
            Functions = functions;
        }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Category { get; set; }

        public string Image { get; set; }
        
        public bool IsOnline { get; set; }

        public string Address { get; set; }

        public string Link { get; set; }

        public List<Ticket> Tickets { get; set; }

        public Producer Producer { get; set; }
        
        public List<Function> Functions { get; set; }

        public static Event CreateEvent(string name, string description, string category, string image, bool isOnline, string address, string link, List<Ticket> tickets, Producer producer)
        {
            Event e = new Event(name, description, category, image, isOnline, address, link, producer, tickets, new List<Function>());

            if (isOnline)
            {
                e.Link = link;
            }
            else
            {
                e.Address = address;
            }

            return e;
        }

        public void AddFunction(Function function)
        {
            if (!FunctionAlreadyExists(function))
            {
                Functions.Add(function);
            }
            else
            {
                throw new ObjectExistsException("Function");
            }
        }

        public bool FunctionAlreadyExists(Function function)
        {
            foreach (Function f in Functions)
            {
                if (f.DateStart.Equals(function.DateStart) && f.DateEnd.Equals(function.DateEnd)) return true;
            }
            return false;
        }

        public void AddTicket(Ticket ticket)
        {
            if (!TicketAlreadyExists(ticket.Name))
            {
                Tickets.Add(ticket);
            }
            else
            {
                throw new ObjectExistsException();
            }
        }

        public bool TicketAlreadyExists(string name)
        {
            foreach (Ticket t in Tickets)
            {
                if (t.Name.Equals(name)) return true;
            }
            return false;
        }

        public int CalculateTotalTickets()
        {
            return Tickets.Sum(ticket => ticket.MaxQuantity);
        }

        /*
        public List<Function> OrderFunctionsByDate()
        {
            return this.Functions.OrderBy(e => e.DateStart).ToList();
        }
        */

        // ToDo Segunda Entrega: NO eliminar las funciones, marcarlas con un flag.
        public List<Function> GetAvailableFunctionsFromNow()
        {
            List<Function> filteredList = new List<Function>();
            foreach (Function f in Functions)
            {
                if ((f.DateStart > DateTime.Now) && f.AvailableTickets > 0)
                {
                    filteredList.Add(f);
                }
                break;
            }

            return filteredList;
        }

        public DateTime CalculateRecentFunctionDate()
        {
            return Functions.Min(f => f.DateStart);
        }

        public override string ToString()
        {
            return Name + " - Functions: " + Functions.Count();
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (!(obj is Event))
            {
                return false;
            }

            return (this.Name == ((Event)obj).Name &&
                    this.Description == ((Event)obj).Description &&
                    this.Address == ((Event)obj).Address &&
                    this.Link == ((Event)obj).Link);
        }
    }
}
