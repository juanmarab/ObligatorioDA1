﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1
{
    public class Function
    {
        public Function(DateTime dateStart, DateTime dateEnd, List<Ticket> tickets, int availableTickets)
        {
            DateStart = dateStart;
            DateEnd = dateEnd;
            Tickets = tickets;
            AvailableTickets = availableTickets;
        }

        public DateTime DateStart { get; set; }

        public DateTime DateEnd { get; set; }

        public List<Ticket> Tickets { get; set; }

        public int AvailableTickets { get; set; }

        public static Function CreateFunction(string startDate, string startHour, string endDate, string endHour, List<Ticket> tickets, int availableTickets)
        {
            DateTime parsedStartDate = Utils.BuildDate(startDate, startHour);
            DateTime parsedEndDate = Utils.BuildDate(endDate, endHour);

            return new Function(parsedStartDate, parsedEndDate, tickets, availableTickets);
        }

        public void DecrementTicketQuantity(string name)
        {
            Ticket ticketToDecrement = GetTicketByName(name);
            if (ticketToDecrement != null)
            {
                ticketToDecrement.Available--;
                Console.WriteLine("Nueva cantidad de Tickets: " + ticketToDecrement.Available);
            }
        }

        public Ticket GetTicketByName(string name)
        {
            try
            {
                return Tickets.First(t => t.Name.Equals(name));
            }
            catch (Exception)
            {
                throw new ObjectNotExistsException("Ticket");
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (!(obj is Function))
            {
                return false;
            }
            return (this.DateStart == ((Function)obj).DateStart)
                && (this.DateEnd == ((Function)obj).DateEnd);
        }

        public override string ToString()
        {
            return "Start: " + DateStart.ToString("yyyy-MM-dd") + " - End: " + DateEnd.ToString("yyyy-MM-dd") + " - Available Tickets: " + AvailableTickets;
        }

        public string PrintTicket()
        {
            return "Start: " + DateStart.ToString("yyyy-MM-dd") + " - End: " + DateEnd.ToString("yyyy-MM-dd");
        }
    }
}
