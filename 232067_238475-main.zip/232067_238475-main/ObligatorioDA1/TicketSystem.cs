﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1
{
    public class TicketSystem
    {

        public TicketSystem(List<Producer> producers, List<Event> events)
        {
            Producers = producers;
            Events = events;
        }

        public TicketSystem()
        {
            Producers = new List<Producer>();
            Events = new List<Event>();
            Buys = new List<Buy>();
        }
        
        public List<Producer> Producers { get; set; } 

        public List<Event> Events { get; set; }

        public static List<Buy> Buys { get; set; }

        public Producer ActiveProducer { get; set; }

        public bool ProducerAlreadyExists(string email)
        {
            foreach (Producer p in Producers)
            {
                if (p.Email.Equals(email)) return true;
            }
            return false;
        }

        public void AddProducer(Producer producer)
        {
            if (!ProducerAlreadyExists(producer.Email))
            {
                Producers.Add(producer);
            }
            else 
            {
                throw new ObjectExistsException();
            }
                
        }

        public bool IsValidPassword(string email, string password)
        {
            if (ProducerAlreadyExists(email))
            {
                foreach (Producer p in Producers)
                {
                    if (p.Email.Equals(email) && p.Password.Equals(password)) return true;
                }
                return false;
            }
            else 
            {
                return false;
            }
        }

        public bool EventAlreadyExists(String eventName)
        {
            foreach (Event e in Events)
            {
                if (e.Name.Equals(eventName)) return true;
            }
            return false;
        }

        public void AddEvent(Event event1)
        {
            Events.Add(event1);
        }

        public bool FunctionAlreadyExists(Event event1, Function function)
        {
            if (EventAlreadyExists(event1.Name))
            {
                foreach (Function f in event1.Functions)
                {
                    if (f.DateStart.Equals(function.DateStart) && f.DateEnd.Equals(function.DateEnd))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public Producer GetProducerByEmail(string email)
        {
            try
            {
                return Producers.First(p => p.Email.Equals(email));
            }
            catch (InvalidOperationException)
            {
                throw new ObjectNotExistsException("producer");
            }
        }

        public List<Event> GetListEventByProducer(Producer producer)
        {
            return this.Events.Where(event1 => event1.Producer == producer).ToList();
        }

        public List<Event> OrderListEventByName()
        {
            List<Event> EventsWithFunctions = new List<Event>();
            foreach (Event event1 in GetAvailableEventsFromNow())
            {
                if (event1.Functions.Count > 0) EventsWithFunctions.Add(event1);
            }
            return EventsWithFunctions.OrderBy(event1 => event1.Name).ToList();
        }

        public List<Event> GetAvailableEventsFromNow()
        {
            List<Event> filteredList = new List<Event>();
            foreach (Event e in Events)
            {
                foreach (Function f in e.Functions)
                {
                    if (f.DateStart > DateTime.Now)
                    {
                        filteredList.Add(e);
                    }
                    break;
                }
            }

            return filteredList;
        }

        /*
        public List<Event> OrderEventListByDate()
        {
            List<Event> listOrdered = new List<Event>();
            DateTime mostRecent = DateTime.MaxValue;

            List<Event> availableEvents = GetAvailableEventsFromNow();

            foreach (Event event1 in availableEvents)
            {
                DateTime mostRecentFunctionInThisEvent;
                if (listOrdered.Count == 0)
                {
                    listOrdered.Add(event1);
                    mostRecent = event1.CalculateRecentFunctionDate();
                }
                else
                {
                    mostRecentFunctionInThisEvent = event1.CalculateRecentFunctionDate();
                    if (mostRecentFunctionInThisEvent < mostRecent)
                    {
                        listOrdered.Insert(0, event1);
                    }
                    else
                    {
                        listOrdered.Add(event1);
                    }
                }
            }
            return listOrdered;
        }
        */

        public static Buy ProcessPayment(List<BuyDetail> buyDetails, string name, string lastname, string id, int total, int quantity)
        {
            Console.WriteLine("Cantidad de BUYS en BD: " + Buys.Count);

            Function ticketsFunction = buyDetails[0].Function;

            foreach (BuyDetail detail in buyDetails)
            {
                Function f = detail.Function;
                f.DecrementTicketQuantity(detail.TicketBought.Name);

            }

            Buy buy = GenerateBuy(name, lastname, id, quantity, total, ticketsFunction, buyDetails);
            return buy;
        }

        public static Buy GenerateBuy(string name, string lastname, string id, int quantity, int total, Function function, List<BuyDetail> buyDetails)
        {
            Buy buy = new Buy(name, lastname, id, quantity, total, function, buyDetails);
            Buys.Add(buy);
            Console.Write("Se creo una Buy de " + quantity + " tickets para la función: " + function);
            Console.Write("Cantidad de BUYS en BD: " + Buys.Count);
            return buy;
        }

    }
}
