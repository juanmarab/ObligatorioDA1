﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ObligatorioDA1
{
    public class BuyDetail
    {
        public BuyDetail(string ticketId, Function function, Ticket ticketBought)
        {
            TicketId = ticketId;
            Function = function;
            TicketBought = ticketBought;
        }

        public static BuyDetail CreateBuyDetail(Function function, Ticket ticketBought)
        {
            string id = Utils.GenerateRandomID();
            
            return new BuyDetail(id, function, ticketBought); 
        }

        public static List<BuyDetail> GenerateTickets(Function selectedFunction, Ticket selectedTicket, int quantity)
        {
            List<BuyDetail> ticketList = new List<BuyDetail>();

            for (int i = 0; i < quantity; i++)
            {
                BuyDetail buyDetail = BuyDetail.CreateBuyDetail(selectedFunction, selectedTicket);
                ticketList.Add(buyDetail);
            }

            return ticketList;
        }

        public static int CalculateTotalCost(List<BuyDetail> BuyDetailList)
        {
            int total = 0;
            foreach (BuyDetail buyDetail in BuyDetailList)
            {
                total += buyDetail.TicketBought.Price;
            }
            return total;
        }
        public string TicketId { get; set; }
        public Function Function { get; set; }
        public Ticket TicketBought { get; set; }

        public override string ToString()
        {
            return TicketId + " - " + TicketBought.Name + " - " + Function.PrintTicket();
        }
    }
}
