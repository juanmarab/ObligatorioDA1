﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1
{
    public class Utils
    {

        private static Random random = new Random();

        public static bool ValidateName(string firstName, string lastName)
        {
            return Regex.IsMatch(firstName, @"^[a-zA-Z]+$") && Regex.IsMatch(lastName, @"^[a-zA-Z]+$"); ;
        }

        public static bool ValidateEmail(string email)
        {
            return Regex.IsMatch(email, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"); ;
        }

        public static bool ValidatePassword(string password)
        {
            return Regex.IsMatch(password, @"[0-9]+") && Regex.IsMatch(password, @".{8,}");
        }

        public static bool ValidateLink(string link)
        {
            try
            {
                Uri uriResult;

                bool result = Uri.TryCreate(link, UriKind.RelativeOrAbsolute, out uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
                Console.WriteLine(result);

                return result;
            } catch (Exception)
            {
                return false;
            }
        }

        public static DateTime BuildDate(string date, string hour)
        {
            string completeDate = date + " " + hour;
            try
            {
                return DateTime.ParseExact(completeDate, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            } catch (Exception)
            {
                throw new InvalidInputException("Date");
            }
        }

        public static string GenerateRandomID()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var stringChars = new char[10];

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(stringChars);
        }
    }
}
