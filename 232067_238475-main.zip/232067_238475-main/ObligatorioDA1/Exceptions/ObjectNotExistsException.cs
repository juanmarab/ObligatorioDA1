﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1.Exceptions
{
    public class ObjectNotExistsException : Exception
    {
        public ObjectNotExistsException()
        { }
        
        public ObjectNotExistsException(string name) :
            base($"Error. This {name} does not exist.")
        {
            Name = name;
        }
        public string Name { get; private set; }
    }
}
