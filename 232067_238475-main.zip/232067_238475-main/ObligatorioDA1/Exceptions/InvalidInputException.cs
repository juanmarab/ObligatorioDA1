﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1.Exceptions
{
    public class InvalidInputException : Exception
    {

        public InvalidInputException(string name) :
            base($"Error. Entered wrong inputs: {name}")
        {
            Name = name;
        }
        public string Name { get; private set; }
    }
}
