﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1.Exceptions
{
    public class ObjectExistsException : Exception
    {
        public ObjectExistsException()
        { }

        public ObjectExistsException(string name) :
            base($"Error. This {name} already exists")
        {
            Name = name;
        }
        public string Name { get; private set; }
    }
}
