﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioDA1
{
    public class Ticket
    {
        public Ticket(string name, int price, int maxQuantity, int available)
        {
            Name = name;
            Price = price;
            MaxQuantity = maxQuantity;
            Available = available;
        }

        public string Name { get; set; }
        
        public int Price { get; set; }
        
        public int MaxQuantity { get; set; }
        
        public int Available { get; set; }

        public override string ToString()
        {
            return Name + " - Price: " + Price + " - Quantity: " + MaxQuantity;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (!(obj is Ticket))
            {
                return false;
            }
            return (this.Name == ((Ticket)obj).Name)
                && (this.Price == ((Ticket)obj).Price);
        }
    }
}
