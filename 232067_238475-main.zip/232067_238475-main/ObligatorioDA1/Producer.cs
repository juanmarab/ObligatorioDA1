﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObligatorioDA1.Exceptions;

namespace ObligatorioDA1
{
    public class Producer
    {
        public Producer(string firstName, string lastName, string email, string password, List<Event> events)
        {
            ProducerInputValidation(firstName, lastName, email, password);
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Password = password;
            Events = events;
        }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public List<Event> Events { get; set; }

        public static bool ProducerInputValidation(string firstName, string lastName, string email, string password)
        {
            return (Utils.ValidateName(firstName, lastName) &&
                Utils.ValidateEmail(email) &&
                Utils.ValidatePassword(password)) ? true : throw new InvalidInputException("Name, Email, or Password");
        }

        public void AddEvent(Event event1)
        {
            Events.Add(event1);
        }

        public override string ToString()
        {
            return FirstName + " " + LastName + " - " + Email;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (!(obj is Producer))
            {
                return false;
            }
            return (this.Email == ((Producer)obj).Email);
        }
    }
}
